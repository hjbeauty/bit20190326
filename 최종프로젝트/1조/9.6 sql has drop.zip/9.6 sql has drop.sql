-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.6-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for babbingdb
CREATE DATABASE IF NOT EXISTS `babbingdb` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `babbingdb`;

-- Dumping structure for table babbingdb.advertisementvo
CREATE TABLE IF NOT EXISTS `advertisementvo` (
  `advertisement_id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `advertisement_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `advertisementname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `advertisement_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `introduce` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `non_members_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `non_members_com` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `profile_img` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'https://www.dropbox.com/s/3udls1t7jm2rjri/Bobbing-main-Circle-shop.gif?dl=1',
  `puted_count` int(11) NOT NULL DEFAULT 0,
  `ad_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `convenience` float DEFAULT 0,
  `evaluation_avg` float DEFAULT 0,
  `flavor` float DEFAULT 0,
  `price` float DEFAULT 0,
  `service` float DEFAULT 0,
  `advertisement_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`advertisement_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table babbingdb.advertisementvo: ~11 rows (approximately)
DELETE FROM `advertisementvo`;
/*!40000 ALTER TABLE `advertisementvo` DISABLE KEYS */;
INSERT INTO `advertisementvo` (`advertisement_id`, `address`, `advertisement_email`, `advertisementname`, `advertisement_num`, `introduce`, `non_members_address`, `non_members_com`, `password`, `profile_img`, `puted_count`, `ad_key`, `convenience`, `evaluation_avg`, `flavor`, `price`, `service`, `advertisement_name`) VALUES
	(1, 'weee address', 'tonyzorz@naver.com', 'itstaewon1', 'whatshouldbeinsertedhere', 'hi guys', NULL, NULL, 'tonyzorz', 'https://www.dropbox.com/s/3udls1t7jm2rjri/Bobbing-main-Circle-shop.gif?dl=1', 2, NULL, 0, 0, 0, 0, 0, NULL),
	(2, 'weee address', 'tonyzorz2@naver.com', 'itstaewon2', 'whatshouldbeinsertedhere', 'hi guys', NULL, NULL, 'tonyzorz2', 'https://www.dropbox.com/s/3udls1t7jm2rjri/Bobbing-main-Circle-shop.gif?dl=1', 3, NULL, 0, 0, 0, 0, 0, NULL),
	(3, 'weee address', 'tonyzorz3@naver.com', '3', 'whatshouldbeinsertedhere', 'hi guys', NULL, NULL, 'tonyzorz3', 'https://www.dropbox.com/s/3udls1t7jm2rjri/Bobbing-main-Circle-shop.gif?dl=1', 5, NULL, 0, 0, 0, 0, 0, NULL),
	(4, 'weee address', 'tonyzorz4@naver.com', '4', 'whatshouldbeinsertedhere', 'hi guys', NULL, NULL, 'tonyzorz4', 'https://www.dropbox.com/s/3udls1t7jm2rjri/Bobbing-main-Circle-shop.gif?dl=1', 3, NULL, 0, 0, 0, 0, 0, NULL),
	(5, 'weee address', 'tonyzorz5@naver.com', 'itstaewon5', 'whatshouldbeinsertedhere', 'hi guys', NULL, NULL, 'tonyzorz5', 'https://www.dropbox.com/s/3udls1t7jm2rjri/Bobbing-main-Circle-shop.gif?dl=1', 5, NULL, 0, 0, 0, 0, 0, NULL),
	(6, 'weee address', 'tonyzorz6@naver.com', 'itstaewon6', 'whatshouldbeinsertedhere', 'hi guys', NULL, NULL, 'tonyzorz6', 'https://www.dropbox.com/s/3udls1t7jm2rjri/Bobbing-main-Circle-shop.gif?dl=1', 6, NULL, 0, 0, 0, 0, 0, NULL),
	(7, 'weee address', 'tonyzorz7@naver.com', 'itstaewon7', 'whatshouldbeinsertedhere', 'hi guys', NULL, NULL, 'tonyzorz7', 'https://www.dropbox.com/s/3udls1t7jm2rjri/Bobbing-main-Circle-shop.gif?dl=1', 7, NULL, 0, 0, 0, 0, 0, NULL),
	(8, 'weee address', 'tonyzorz8@naver.com', 'itstaewon', 'whatshouldbeinsertedhere', 'hi guys', NULL, NULL, 'tonyzorz8', 'https://www.dropbox.com/s/3udls1t7jm2rjri/Bobbing-main-Circle-shop.gif?dl=1', 9, NULL, 0, 0, 0, 0, 0, NULL),
	(9, 'weee address', 'tonyzorz9@naver.com', 'itstaewon', 'whatshouldbeinsertedhere', 'hi guys', NULL, NULL, 'tonyzorz9', 'https://www.dropbox.com/s/3udls1t7jm2rjri/Bobbing-main-Circle-shop.gif?dl=1', 10, NULL, 0, 0, 0, 0, 0, NULL),
	(10, NULL, 'kjk0656@naver.com', '강남불백', '22222222', NULL, NULL, NULL, '615ed7fb1504b0c724a296d7a69e6c7b2f9ea2c57c1d8206c5afdf392ebdfd25', 'https://www.dropbox.com/s/3udls1t7jm2rjri/Bobbing-main-Circle-shop.gif?dl=1', 0, 'Y', 0, 0, 0, 0, 0, NULL),
	(20, NULL, 'bumzzings@naver.com', '유주마켓', '1243123456', NULL, NULL, NULL, '28f0116ef42bf718324946f13d787a1d41274a08335d52ee833d5b577f02a32a', 'https://www.dropbox.com/s/3udls1t7jm2rjri/Bobbing-main-Circle-shop.gif?dl=1', 0, 'Y', 0, 0, 0, 0, 0, NULL),
	(21, NULL, 'tonyzorz951@naver.com', '태원기업', '88888888', NULL, NULL, NULL, '615ed7fb1504b0c724a296d7a69e6c7b2f9ea2c57c1d8206c5afdf392ebdfd25', 'https://www.dropbox.com/s/3udls1t7jm2rjri/Bobbing-main-Circle-shop.gif?dl=1', 0, 'Y', 0, 0, 0, 0, 0, NULL);
/*!40000 ALTER TABLE `advertisementvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.advertisement_evaluationvo
CREATE TABLE IF NOT EXISTS `advertisement_evaluationvo` (
  `evaluation_id` int(11) NOT NULL AUTO_INCREMENT,
  `advertisement_id` int(11) NOT NULL,
  `convenience` float NOT NULL,
  `demerit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `envaluation_avg` float NOT NULL,
  `evaluation_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flavor` float NOT NULL,
  `merit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` float NOT NULL,
  `service` float NOT NULL,
  PRIMARY KEY (`evaluation_id`),
  KEY `FKo0ugfpgtgokvolxmaf19uxg60` (`advertisement_id`),
  CONSTRAINT `FKo0ugfpgtgokvolxmaf19uxg60` FOREIGN KEY (`advertisement_id`) REFERENCES `advertisementvo` (`advertisement_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table babbingdb.advertisement_evaluationvo: ~8 rows (approximately)
DELETE FROM `advertisement_evaluationvo`;
/*!40000 ALTER TABLE `advertisement_evaluationvo` DISABLE KEYS */;
INSERT INTO `advertisement_evaluationvo` (`evaluation_id`, `advertisement_id`, `convenience`, `demerit`, `envaluation_avg`, `evaluation_comment`, `flavor`, `merit`, `price`, `service`) VALUES
	(1, 1, 4, 'bad', 5, 'good', 1, 'good', 2, 3),
	(2, 2, 4, 'bad', 5, 'good', 1, 'good', 2, 3),
	(3, 3, 4, 'bad', 5, 'good', 1, 'good', 2, 3),
	(4, 4, 4, 'bad', 5, 'good', 1, 'good', 2, 3),
	(5, 5, 4, 'bad', 5, 'good', 1, 'good', 2, 3),
	(6, 6, 4, 'bad', 5, 'good', 1, 'good', 2, 3),
	(7, 7, 4, 'bad', 5, 'good', 1, 'good', 2, 3),
	(8, 8, 4, 'bad', 5, 'good', 1, 'good', 2, 3);
/*!40000 ALTER TABLE `advertisement_evaluationvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.ajax_review_imagevo
CREATE TABLE IF NOT EXISTS `ajax_review_imagevo` (
  `ajax_review_img_id` int(11) NOT NULL AUTO_INCREMENT,
  `ajax_review_img` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `review_id` int(11) NOT NULL,
  PRIMARY KEY (`ajax_review_img_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- Dumping data for table babbingdb.ajax_review_imagevo: ~0 rows (approximately)
DELETE FROM `ajax_review_imagevo`;
/*!40000 ALTER TABLE `ajax_review_imagevo` DISABLE KEYS */;
INSERT INTO `ajax_review_imagevo` (`ajax_review_img_id`, `ajax_review_img`, `review_id`) VALUES
	(13, '/2019/09/20/2e3a03f1-8360-44fa-b5fb-153e8a108745_maxresdefault.jpg', 135);
/*!40000 ALTER TABLE `ajax_review_imagevo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.business_fieldvo
CREATE TABLE IF NOT EXISTS `business_fieldvo` (
  `business_field_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `business_field_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business_field_chk` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business_field_chn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business_field_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business_field_fst` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business_field_ind` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business_field_jpn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business_field_paz` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business_field_sea` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business_field_snk` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business_field_wes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`business_field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table babbingdb.business_fieldvo: ~14 rows (approximately)
DELETE FROM `business_fieldvo`;
/*!40000 ALTER TABLE `business_fieldvo` DISABLE KEYS */;
INSERT INTO `business_fieldvo` (`business_field_id`, `business_field_name`, `business_field_chk`, `business_field_chn`, `business_field_code`, `business_field_fst`, `business_field_ind`, `business_field_jpn`, `business_field_paz`, `business_field_sea`, `business_field_snk`, `business_field_wes`) VALUES
	('caf', '카페', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('chk', '치킨', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('chn', '중식', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('etc', '기타', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('fst', '페스트푸드', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('ind', '인도', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('jpn', '일식', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('kor', '한식', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('nsk', '야식', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('paz', '피자', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('pub', '주점', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('sea', '동남아', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('snk', '분식', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('wes', '양식', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `business_fieldvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.campaignvo
CREATE TABLE IF NOT EXISTS `campaignvo` (
  `campaign_id` int(11) NOT NULL AUTO_INCREMENT,
  `end_date` datetime DEFAULT NULL,
  `introduction` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `offer_history` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `participants` int(11) DEFAULT 0,
  `recruitment` int(11) NOT NULL DEFAULT 0,
  `remarks` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `write_date` datetime DEFAULT current_timestamp(),
  `advertisement_id` int(11) NOT NULL,
  PRIMARY KEY (`campaign_id`),
  KEY `FKryk756wa1gs38hl6qo3on01d4` (`advertisement_id`),
  CONSTRAINT `FKryk756wa1gs38hl6qo3on01d4` FOREIGN KEY (`advertisement_id`) REFERENCES `advertisementvo` (`advertisement_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;

-- Dumping data for table babbingdb.campaignvo: ~9 rows (approximately)
DELETE FROM `campaignvo`;
/*!40000 ALTER TABLE `campaignvo` DISABLE KEYS */;
INSERT INTO `campaignvo` (`campaign_id`, `end_date`, `introduction`, `modified_date`, `offer_history`, `participants`, `recruitment`, `remarks`, `start_date`, `title`, `write_date`, `advertisement_id`) VALUES
	(2, '2019-09-27 00:00:00', '유유', NULL, 'ㅇㅇㅇ', 0, 5, '', '2019-09-24 00:00:00', '왜 안되냐', '2019-09-18 19:37:42', 1),
	(3, '2019-09-27 00:00:00', '헬로우 헬로우\r\n만나서 반갑습니다.', NULL, '\r\n대한민국 최고의 걸그룹 여자친구', 0, 15, '\r\n수록곡 맛집', '2019-09-24 00:00:00', '테스트', '2019-09-18 20:31:25', 1),
	(4, '2019-10-15 00:00:00', '너 그리고 나\r\n오늘부터 우리는\r\n열대야', '2019-09-19 09:30:18', '랜덤 포토카드 1종', 0, 5, '', '2019-10-01 00:00:00', '앨범 커버 모음', '2019-09-19 09:29:50', 1),
	(5, '2019-09-22 00:00:00', '항상\r\n그대 안에\r\n피고 지는 꽃\r\n', NULL, '랜덤 포토카드 1종', 0, 10, '', '2019-09-20 00:00:00', 'Flower', '2019-09-19 09:33:21', 1),
	(6, '2019-09-22 00:00:00', '항상\r\n그대 안에\r\n피고 지는 꽃\r\n', NULL, '랜덤 포토카드 1종', 0, 10, '', '2019-09-20 00:00:00', 'Flower', '2019-09-19 09:33:21', 1),
	(7, '2019-09-22 00:00:00', '항상\r\n그대 안에\r\n피고 지는 꽃\r\n', NULL, '랜덤 포토카드 1종', 0, 10, '', '2019-09-20 00:00:00', 'Flower', '2019-09-19 09:33:21', 1),
	(8, '2019-09-22 00:00:00', '항상\r\n그대 안에\r\n피고 지는 꽃\r\n', NULL, '랜덤 포토카드 1종', 0, 10, '', '2019-09-20 00:00:00', 'Flower', '2019-09-19 09:33:21', 1),
	(9, '2019-09-22 00:00:00', '항상\r\n그대 안에\r\n피고 지는 꽃\r\n', NULL, '랜덤 포토카드 1종', 0, 10, '', '2019-09-20 00:00:00', 'Flower', '2019-09-19 09:33:21', 1),
	(52, '2019-09-30 00:00:00', '출근길', NULL, '4장의 사진', 0, 12, 'ㅎ_ㅎ', '2019-09-25 00:00:00', '테스트 190919', '2019-09-19 16:46:19', 20),
	(54, '2019-09-28 00:00:00', 'ㅎㅇ', NULL, '4장의 사진', 0, 5, '그렇게 쉽게 깨지진 않을꺼야`', '2019-09-23 00:00:00', '아이피 접속', '2019-09-19 16:52:37', 20);
/*!40000 ALTER TABLE `campaignvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.campaign_alarmvo
CREATE TABLE IF NOT EXISTS `campaign_alarmvo` (
  `campaign_alarm_id` int(11) NOT NULL AUTO_INCREMENT,
  `advertisement_id` int(11) NOT NULL,
  `alarm_context` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `alarm_receive_time` datetime DEFAULT NULL,
  `alarm_send_time` datetime DEFAULT NULL,
  `campaign_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`campaign_alarm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table babbingdb.campaign_alarmvo: ~0 rows (approximately)
DELETE FROM `campaign_alarmvo`;
/*!40000 ALTER TABLE `campaign_alarmvo` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_alarmvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.campaign_imgvo
CREATE TABLE IF NOT EXISTS `campaign_imgvo` (
  `campaign_img_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL,
  `campaign_img` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`campaign_img_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

-- Dumping data for table babbingdb.campaign_imgvo: ~17 rows (approximately)
DELETE FROM `campaign_imgvo`;
/*!40000 ALTER TABLE `campaign_imgvo` DISABLE KEYS */;
INSERT INTO `campaign_imgvo` (`campaign_img_id`, `campaign_id`, `campaign_img`) VALUES
	(1, 2, 'campaignImages\\d1220952-763d-42df-a288-5635ee695aad_gf22.jpg'),
	(2, 2, 'campaignImages\\63ad7cb5-f09a-4b89-802b-bc02c70f04c3_gf23.jpg'),
	(3, 3, 'campaignImages\\c3cddced-e4ab-46a7-93b3-26429727139a_gf12.jpg'),
	(4, 3, 'campaignImages\\c46a263b-4322-48fd-8952-3d8e645ceda0_gf13.jpg'),
	(5, 4, 'campaignImages\\de85751a-c9f0-4bb0-8bf7-1caf4d331091_gf03.jpg'),
	(6, 4, 'campaignImages\\cea9d52b-2a41-4e98-95c3-a531fe4a955b_gf07.jpg'),
	(7, 4, 'campaignImages\\a7e06bfd-7d02-48b2-a3a9-5b06b1008506_gf27.jpg'),
	(8, 4, 'campaignImages\\b7319780-c319-416c-b8bb-8df7ac7b91b6_gf29.jpg'),
	(9, 5, 'campaignImages\\b7319780-c319-416c-b8bb-8df7ac7b91b6_gf29.jpg'),
	(10, 6, 'campaignImages\\b7319780-c319-416c-b8bb-8df7ac7b91b6_gf29.jpg'),
	(11, 7, 'campaignImages\\b7319780-c319-416c-b8bb-8df7ac7b91b6_gf29.jpg'),
	(12, 8, 'campaignImages\\b7319780-c319-416c-b8bb-8df7ac7b91b6_gf29.jpg'),
	(13, 9, 'campaignImages\\b7319780-c319-416c-b8bb-8df7ac7b91b6_gf29.jpg'),
	(47, 52, 'campaignImages\\1e0276e4-903a-4313-ba29-c40ba9e98064_gf04.jpg'),
	(48, 53, 'campaignImages\\47d9f21c-6854-4e9e-b6e3-cddba24255fe_gf13.jpg'),
	(49, 54, 'campaignImages\\3e19da26-d37d-46f9-83d0-299bab5ced9e_gf12.jpg'),
	(50, 54, 'campaignImages\\b6705a60-0972-45e2-8612-53f693f4764f_gf13.jpg'),
	(51, 54, 'campaignImages\\f4b84e77-ba9c-4c39-89d5-bddd7d54b794_gf14.jpg');
/*!40000 ALTER TABLE `campaign_imgvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.commentvo
CREATE TABLE IF NOT EXISTS `commentvo` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `contents` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `write_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `nickname` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `FK7kmsnqyunfo7chb3b40e9msoq` (`review_id`),
  KEY `FKicbnk28lebweaj6nq0fxknfu3` (`user_id`),
  CONSTRAINT `FK7kmsnqyunfo7chb3b40e9msoq` FOREIGN KEY (`review_id`) REFERENCES `review_registrationvo` (`review_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FKicbnk28lebweaj6nq0fxknfu3` FOREIGN KEY (`user_id`) REFERENCES `uservo` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Dumping data for table babbingdb.commentvo: ~0 rows (approximately)
DELETE FROM `commentvo`;
/*!40000 ALTER TABLE `commentvo` DISABLE KEYS */;
/*!40000 ALTER TABLE `commentvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.comment_alarmvo
CREATE TABLE IF NOT EXISTS `comment_alarmvo` (
  `comment_alarm_id` int(11) NOT NULL AUTO_INCREMENT,
  `advertisement_id` int(11) NOT NULL,
  `alarm_context` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `alarm_receive_time` datetime DEFAULT NULL,
  `alarm_send_time` datetime DEFAULT NULL,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`comment_alarm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table babbingdb.comment_alarmvo: ~0 rows (approximately)
DELETE FROM `comment_alarmvo`;
/*!40000 ALTER TABLE `comment_alarmvo` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment_alarmvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.followvo
CREATE TABLE IF NOT EXISTS `followvo` (
  `follow_id` int(11) NOT NULL AUTO_INCREMENT,
  `following_time` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `follower_me` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `following_you` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`follow_id`)
) ENGINE=InnoDB AUTO_INCREMENT=371 DEFAULT CHARSET=utf8;

-- Dumping data for table babbingdb.followvo: ~32 rows (approximately)
DELETE FROM `followvo`;
/*!40000 ALTER TABLE `followvo` DISABLE KEYS */;
INSERT INTO `followvo` (`follow_id`, `following_time`, `follower_me`, `following_you`) VALUES
	(213, NULL, 'taewon', 'bumhong'),
	(220, NULL, 'taewon', 'tonyzorz'),
	(225, NULL, 'bumhong', 'taewon'),
	(226, NULL, 'bumhong', 'jinkwang'),
	(228, NULL, 'bumhong', 'sungha'),
	(238, NULL, 'bumhong', 'tonyzorz'),
	(240, NULL, 'tonyzorz', 'itstaewon'),
	(242, NULL, 'tonyzorz', 'itstaewon1'),
	(246, NULL, 'tonyzorz', 'tonyzorzzz'),
	(275, NULL, 'tonyzorz', ''),
	(290, NULL, 'jinkwang', 'bumhong'),
	(292, NULL, 'jinkwang', 'taewon'),
	(293, NULL, 'taewon', 'jinkwang'),
	(294, NULL, 'taewon', 'tonyzorzzz'),
	(295, NULL, 'taewon', 'tony'),
	(296, NULL, 'taewon', 'sungha'),
	(297, NULL, 'taewon', 'ujin'),
	(299, NULL, 'tonyzorz', 'tony'),
	(302, NULL, 'tonyzorz', 'bumhong'),
	(310, NULL, 'org.thymeleaf.context.WebEngineContext$SessionAttributesMap@44ff7932', 'jinkwang'),
	(325, NULL, 'tonyzorz', 'sungha'),
	(326, NULL, 'tonyzorz', 'taewon'),
	(333, NULL, 'improve', 'samurai'),
	(337, NULL, 'improve', 'ujin'),
	(360, NULL, 'improve', 'tonyzorz'),
	(362, NULL, 'improve', 'bumhong'),
	(365, NULL, 'improve', 'yuju'),
	(366, NULL, 'improve', 'taewon'),
	(367, NULL, 'samurai', 'ujin'),
	(368, NULL, 'samurai', 'tonyzorzzz'),
	(369, NULL, 'samurai', 'improve'),
	(370, NULL, 'samurai', 'yuju');
/*!40000 ALTER TABLE `followvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.follow_alarmvo
CREATE TABLE IF NOT EXISTS `follow_alarmvo` (
  `follow_alarm_id` int(11) NOT NULL AUTO_INCREMENT,
  `advertisement_id` int(11) NOT NULL,
  `alarm_context` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `alarm_receive_time` datetime DEFAULT NULL,
  `alarm_send_time` datetime DEFAULT NULL,
  `follow_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`follow_alarm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table babbingdb.follow_alarmvo: ~0 rows (approximately)
DELETE FROM `follow_alarmvo`;
/*!40000 ALTER TABLE `follow_alarmvo` DISABLE KEYS */;
/*!40000 ALTER TABLE `follow_alarmvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.hibernate_sequence
CREATE TABLE IF NOT EXISTS `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table babbingdb.hibernate_sequence: ~0 rows (approximately)
DELETE FROM `hibernate_sequence`;
/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;

-- Dumping structure for table babbingdb.likevo
CREATE TABLE IF NOT EXISTS `likevo` (
  `like_id` int(11) NOT NULL AUTO_INCREMENT,
  `like_time` datetime DEFAULT NULL,
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`like_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table babbingdb.likevo: ~0 rows (approximately)
DELETE FROM `likevo`;
/*!40000 ALTER TABLE `likevo` DISABLE KEYS */;
/*!40000 ALTER TABLE `likevo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.like_alarmvo
CREATE TABLE IF NOT EXISTS `like_alarmvo` (
  `like_alarm_id` int(11) NOT NULL,
  `advertisement_id` int(11) NOT NULL,
  `alarm_context` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alarm_receive_time` datetime DEFAULT NULL,
  `alarm_send_time` datetime DEFAULT NULL,
  `like_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`like_alarm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table babbingdb.like_alarmvo: ~0 rows (approximately)
DELETE FROM `like_alarmvo`;
/*!40000 ALTER TABLE `like_alarmvo` DISABLE KEYS */;
/*!40000 ALTER TABLE `like_alarmvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.participantsvo
CREATE TABLE IF NOT EXISTS `participantsvo` (
  `participants_id` int(11) NOT NULL AUTO_INCREMENT,
  `participation` char(1) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `campaign_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`participants_id`),
  KEY `FKojnu4gdvfh1hpc6t4wili07rt` (`campaign_id`),
  KEY `FK417gx6b6lgcxvrqym8xm7suyo` (`user_id`),
  CONSTRAINT `FK417gx6b6lgcxvrqym8xm7suyo` FOREIGN KEY (`user_id`) REFERENCES `uservo` (`user_id`),
  CONSTRAINT `FKojnu4gdvfh1hpc6t4wili07rt` FOREIGN KEY (`campaign_id`) REFERENCES `campaignvo` (`campaign_id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;

-- Dumping data for table babbingdb.participantsvo: ~0 rows (approximately)
DELETE FROM `participantsvo`;
/*!40000 ALTER TABLE `participantsvo` DISABLE KEYS */;
/*!40000 ALTER TABLE `participantsvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.putvo
CREATE TABLE IF NOT EXISTS `putvo` (
  `put_id` int(11) NOT NULL AUTO_INCREMENT,
  `put_time` datetime DEFAULT NULL,
  `advertisement_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`put_id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table babbingdb.putvo: ~17 rows (approximately)
DELETE FROM `putvo`;
/*!40000 ALTER TABLE `putvo` DISABLE KEYS */;
INSERT INTO `putvo` (`put_id`, `put_time`, `advertisement_name`, `user_name`) VALUES
	(3, NULL, 'itstaewon1', 'tonyzorz'),
	(18, NULL, '3', 'tonyzorz'),
	(22, NULL, 'itstaewon', 'tonyzorz'),
	(33, NULL, '', 'tonyzorz'),
	(34, NULL, '4', 'tonyzorz'),
	(35, NULL, 'itstaewon2', 'tonyzorz'),
	(36, NULL, '3', 'jinkwang'),
	(37, NULL, 'itstaewon2', 'jinkwang'),
	(38, NULL, '4', 'jinkwang'),
	(39, NULL, 'itstaewon5', 'jinkwang'),
	(40, NULL, 'itstaewon', 'jinkwang'),
	(93, NULL, 'itstaewon5', 'improve'),
	(98, NULL, '강남불백', 'improve'),
	(100, NULL, '태원기업', 'improve'),
	(101, NULL, 'itstaewon1', 'improve'),
	(125, NULL, 'itstaewon2', 'improve');
/*!40000 ALTER TABLE `putvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.review_alarmvo
CREATE TABLE IF NOT EXISTS `review_alarmvo` (
  `review_alarm_id` int(11) NOT NULL,
  `advertisement_id` int(11) NOT NULL,
  `alarm_context` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alarm_receive_time` datetime DEFAULT NULL,
  `alarm_send_time` datetime DEFAULT NULL,
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`review_alarm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table babbingdb.review_alarmvo: ~0 rows (approximately)
DELETE FROM `review_alarmvo`;
/*!40000 ALTER TABLE `review_alarmvo` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_alarmvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.review_imagevo
CREATE TABLE IF NOT EXISTS `review_imagevo` (
  `img_id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_review` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `review_id` int(11) NOT NULL,
  PRIMARY KEY (`img_id`),
  KEY `FK12t8uwc0xqu74ij4qny8ha3y2` (`review_id`),
  CONSTRAINT `FK12t8uwc0xqu74ij4qny8ha3y2` FOREIGN KEY (`review_id`) REFERENCES `review_registrationvo` (`review_id`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table babbingdb.review_imagevo: ~125 rows (approximately)
DELETE FROM `review_imagevo`;
/*!40000 ALTER TABLE `review_imagevo` DISABLE KEYS */;
INSERT INTO `review_imagevo` (`img_id`, `img`, `img_review`, `review_id`) VALUES
	(1, 'https://www.dropbox.com/s/1g134mqn1g8mqg1/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A82.png?dl=1', '가데이타다 들어가서 나중에 수정안했으면 좋겠네요...', 1),
	(3, 'https://www.dropbox.com/s/rg3sgpebnnjsms3/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A84.png?dl=1', '하하하하아마아아아마암 졸리다', 3),
	(4, 'https://www.dropbox.com/s/ehpxa3uf79yxd63/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A87.png?dl=1', '빨리끝내자', 2),
	(5, 'https://www.dropbox.com/s/swup4xnvcxuwo3a/%EC%8B%A0%EB%8F%99%EA%B6%81%EA%B0%90%EC%9E%90%ED%83%95_%EC%84%A0%EB%A6%895.png?dl=1', '이십대때 아이락 스태디', 4),
	(6, 'https://www.dropbox.com/s/6sqrusz54qf1iwn/%EC%9E%90%EC%97%B0%EB%B3%84%EA%B3%A1_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B88.png?dl=1', '아아아아아아아아아앙', 5),
	(7, 'https://www.dropbox.com/s/52altukubct5tjv/%EC%A1%B0%EA%B0%9C%EC%8B%A0%ED%99%94_%EA%B0%80%EB%A1%9C%EC%88%98%EA%B8%B81.png?dl=1', 'yilhaela taewon', 6),
	(8, 'https://www.dropbox.com/s/rjvgl6p6beisrju/%EC%A1%B0%EA%B0%9C%EC%8B%A0%ED%99%94_%EA%B0%80%EB%A1%9C%EC%88%98%EA%B8%B810.png?dl=1', 'I have to stop djdjdjjdjd', 7),
	(9, 'https://www.dropbox.com/s/7h5d695phx3703h/%ED%9B%88%EB%82%A8%EB%8B%AD%EB%B0%9C_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B83.png?dl=1', 'three more weeks till it all ends', 8),
	(10, 'https://www.dropbox.com/s/iktk70rdfaaohlm/%ED%9B%88%EB%82%A8%EB%8B%AD%EB%B0%9C_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B88.png?dl=1', 'don’t ignore me ', 9),
	(11, 'https://www.dropbox.com/s/nmf0in1iau7ihbt/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A81.png?dl=1', 'late', 10),
	(12, 'https://www.dropbox.com/s/x42p9uckqk9wscc/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A83.png?dl=1', 'im me and you are me', 11),
	(13, 'https://www.dropbox.com/s/w1r0z4v4sk68tzg/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A89.png?dl=1', 'ahahahahah', 12),
	(14, 'https://www.dropbox.com/s/2dig5c42ppkcuv6/%EC%9B%90%ED%82%A4%EC%B9%9C_%EC%84%9C%EC%B4%88_%EC%BB%A4%EB%A6%AC3.png?dl=1', 'sdkfjksjdfsdfjk?', 13),
	(15, 'https://www.dropbox.com/s/de0nrifhszabhos/%EB%9D%BC%EB%B6%80%EC%95%84%EB%9C%A8_%EC%95%95%EA%B5%AC%EC%A0%952.png?dl=1', '위이위잉 사이렌', 14),
	(16, 'https://www.dropbox.com/s/ulz9e752kvha8tr/%EB%A9%94%EC%A2%85%EB%93%9C%EB%A9%94%EB%A5%B4_%EC%84%9C%EC%B4%881.png?dl=1', '이츠 밑바닥', 15),
	(17, 'https://www.dropbox.com/s/89ywmgnvwc1t5am/%EB%A9%94%EC%A2%85%EB%93%9C%EB%A9%94%EB%A5%B4_%EC%84%9C%EC%B4%8811.png?dl=1', '몸농런아러니마얼', 16),
	(18, 'https://www.dropbox.com/s/2z3fnvqocbmk5ai/%EB%B2%84%ED%84%B0%ED%95%91%EA%B1%B0%ED%8C%AC%EC%BC%80%EC%9D%B4%ED%81%AC_%EA%B0%95%EB%82%A87.png?dl=1', 'ㄷ림팀', 17),
	(19, 'https://www.dropbox.com/s/ungm8zoj1gb185l/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A810.png?dl=1', 'that’s just how we roll m?', 18),
	(20, 'https://www.dropbox.com/s/4vjiy3sdplbum3y/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A813.png?dl=1', 'daslkdjflksj', 19),
	(21, 'https://www.dropbox.com/s/4vjiy3sdplbum3y/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A813.png?dl=1', 'LAST ONE WEEEEEEEE', 20),
	(22, 'https://www.dropbox.com/s/1g134mqn1g8mqg1/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A82.png?dl=1', '가데이타다 들어가서 나중에 수정안했으면 좋겠네요...', 21),
	(23, 'https://www.dropbox.com/s/ofd6o278unpsv3g/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A83.png?dl=1', '이렇게 몇번을 더 써야할까요?', 21),
	(24, 'https://www.dropbox.com/s/rg3sgpebnnjsms3/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A84.png?dl=1', '하하하하아마아아아마암 졸리다', 23),
	(25, 'https://www.dropbox.com/s/ehpxa3uf79yxd63/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A87.png?dl=1', '빨리끝내자', 22),
	(26, 'https://www.dropbox.com/s/swup4xnvcxuwo3a/%EC%8B%A0%EB%8F%99%EA%B6%81%EA%B0%90%EC%9E%90%ED%83%95_%EC%84%A0%EB%A6%895.png?dl=1', '이십대때 아이락 스태디', 24),
	(27, 'https://www.dropbox.com/s/6sqrusz54qf1iwn/%EC%9E%90%EC%97%B0%EB%B3%84%EA%B3%A1_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B88.png?dl=1', '아아아아아아아아아앙', 25),
	(28, 'https://www.dropbox.com/s/52altukubct5tjv/%EC%A1%B0%EA%B0%9C%EC%8B%A0%ED%99%94_%EA%B0%80%EB%A1%9C%EC%88%98%EA%B8%B81.png?dl=1', 'yilhaela taewon', 26),
	(29, 'https://www.dropbox.com/s/rjvgl6p6beisrju/%EC%A1%B0%EA%B0%9C%EC%8B%A0%ED%99%94_%EA%B0%80%EB%A1%9C%EC%88%98%EA%B8%B810.png?dl=1', 'I have to stop djdjdjjdjd', 27),
	(30, 'https://www.dropbox.com/s/7h5d695phx3703h/%ED%9B%88%EB%82%A8%EB%8B%AD%EB%B0%9C_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B83.png?dl=1', 'three more weeks till it all ends', 28),
	(31, 'https://www.dropbox.com/s/iktk70rdfaaohlm/%ED%9B%88%EB%82%A8%EB%8B%AD%EB%B0%9C_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B88.png?dl=1', 'don’t ignore me ', 29),
	(32, 'https://www.dropbox.com/s/x42p9uckqk9wscc/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A83.png?dl=1', 'im me and you are me', 31),
	(33, 'https://www.dropbox.com/s/w1r0z4v4sk68tzg/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A89.png?dl=1', 'ahahahahah', 32),
	(34, 'https://www.dropbox.com/s/2dig5c42ppkcuv6/%EC%9B%90%ED%82%A4%EC%B9%9C_%EC%84%9C%EC%B4%88_%EC%BB%A4%EB%A6%AC3.png?dl=1', 'sdkfjksjdfsdfjk?', 33),
	(35, 'https://www.dropbox.com/s/de0nrifhszabhos/%EB%9D%BC%EB%B6%80%EC%95%84%EB%9C%A8_%EC%95%95%EA%B5%AC%EC%A0%952.png?dl=1', '위이위잉 사이렌', 34),
	(36, 'https://www.dropbox.com/s/ulz9e752kvha8tr/%EB%A9%94%EC%A2%85%EB%93%9C%EB%A9%94%EB%A5%B4_%EC%84%9C%EC%B4%881.png?dl=1', '이츠 밑바닥', 35),
	(37, 'https://www.dropbox.com/s/89ywmgnvwc1t5am/%EB%A9%94%EC%A2%85%EB%93%9C%EB%A9%94%EB%A5%B4_%EC%84%9C%EC%B4%8811.png?dl=1', '몸농런아러니마얼', 36),
	(38, 'https://www.dropbox.com/s/2z3fnvqocbmk5ai/%EB%B2%84%ED%84%B0%ED%95%91%EA%B1%B0%ED%8C%AC%EC%BC%80%EC%9D%B4%ED%81%AC_%EA%B0%95%EB%82%A87.png?dl=1', 'ㄷ림팀', 37),
	(39, 'https://www.dropbox.com/s/ungm8zoj1gb185l/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A810.png?dl=1', 'that’s just how we roll m?', 38),
	(40, 'https://www.dropbox.com/s/4vjiy3sdplbum3y/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A813.png?dl=1', 'daslkdjflksj', 39),
	(41, 'https://www.dropbox.com/s/4vjiy3sdplbum3y/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A813.png?dl=1', 'LAST ONE WEEEEEEEE', 40),
	(42, 'https://www.dropbox.com/s/1g134mqn1g8mqg1/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A82.png?dl=1', '가데이타다 들어가서 나중에 수정안했으면 좋겠네요...', 41),
	(43, 'https://www.dropbox.com/s/ofd6o278unpsv3g/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A83.png?dl=1', '이렇게 몇번을 더 써야할까요?', 41),
	(44, 'https://www.dropbox.com/s/rg3sgpebnnjsms3/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A84.png?dl=1', '하하하하아마아아아마암 졸리다', 43),
	(45, 'https://www.dropbox.com/s/ehpxa3uf79yxd63/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A87.png?dl=1', '빨리끝내자', 42),
	(46, 'https://www.dropbox.com/s/swup4xnvcxuwo3a/%EC%8B%A0%EB%8F%99%EA%B6%81%EA%B0%90%EC%9E%90%ED%83%95_%EC%84%A0%EB%A6%895.png?dl=1', '이십대때 아이락 스태디', 44),
	(47, 'https://www.dropbox.com/s/6sqrusz54qf1iwn/%EC%9E%90%EC%97%B0%EB%B3%84%EA%B3%A1_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B88.png?dl=1', '아아아아아아아아아앙', 45),
	(48, 'https://www.dropbox.com/s/52altukubct5tjv/%EC%A1%B0%EA%B0%9C%EC%8B%A0%ED%99%94_%EA%B0%80%EB%A1%9C%EC%88%98%EA%B8%B81.png?dl=1', 'yilhaela taewon', 46),
	(49, 'https://www.dropbox.com/s/rjvgl6p6beisrju/%EC%A1%B0%EA%B0%9C%EC%8B%A0%ED%99%94_%EA%B0%80%EB%A1%9C%EC%88%98%EA%B8%B810.png?dl=1', 'I have to stop djdjdjjdjd', 47),
	(50, 'https://www.dropbox.com/s/7h5d695phx3703h/%ED%9B%88%EB%82%A8%EB%8B%AD%EB%B0%9C_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B83.png?dl=1', 'three more weeks till it all ends', 48),
	(51, 'https://www.dropbox.com/s/iktk70rdfaaohlm/%ED%9B%88%EB%82%A8%EB%8B%AD%EB%B0%9C_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B88.png?dl=1', 'don’t ignore me ', 49),
	(52, 'https://www.dropbox.com/s/nmf0in1iau7ihbt/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A81.png?dl=1', 'late', 50),
	(53, 'https://www.dropbox.com/s/x42p9uckqk9wscc/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A83.png?dl=1', 'imand you are me', 51),
	(54, 'https://www.dropbox.com/s/w1r0z4v4sk68tzg/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A89.png?dl=1', 'ahahahahah', 52),
	(55, 'https://www.dropbox.com/s/2dig5c42ppkcuv6/%EC%9B%90%ED%82%A4%EC%B9%9C_%EC%84%9C%EC%B4%88_%EC%BB%A4%EB%A6%AC3.png?dl=1', 'sdkfjksjdfsdfjk?', 53),
	(56, 'https://www.dropbox.com/s/de0nrifhszabhos/%EB%9D%BC%EB%B6%80%EC%95%84%EB%9C%A8_%EC%95%95%EA%B5%AC%EC%A0%952.png?dl=1', '위이위잉 사이렌', 54),
	(57, 'https://www.dropbox.com/s/ulz9e752kvha8tr/%EB%A9%94%EC%A2%85%EB%93%9C%EB%A9%94%EB%A5%B4_%EC%84%9C%EC%B4%881.png?dl=1', '이츠 밑바닥', 55),
	(58, 'https://www.dropbox.com/s/89ywmgnvwc1t5am/%EB%A9%94%EC%A2%85%EB%93%9C%EB%A9%94%EB%A5%B4_%EC%84%9C%EC%B4%8811.png?dl=1', '몸농런아러니마얼', 56),
	(59, 'https://www.dropbox.com/s/2z3fnvqocbmk5ai/%EB%B2%84%ED%84%B0%ED%95%91%EA%B1%B0%ED%8C%AC%EC%BC%80%EC%9D%B4%ED%81%AC_%EA%B0%95%EB%82%A87.png?dl=1', 'ㄷ림팀', 57),
	(60, 'https://www.dropbox.com/s/ungm8zoj1gb185l/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A810.png?dl=1', 'that’s just how we roll m?', 58),
	(61, 'https://www.dropbox.com/s/4vjiy3sdplbum3y/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A813.png?dl=1', 'daslkdjflksj', 59),
	(62, 'https://www.dropbox.com/s/4vjiy3sdplbum3y/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A813.png?dl=1', 'LAST ONE WEEEEEEEE', 60),
	(63, 'https://www.dropbox.com/s/1g134mqn1g8mqg1/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A82.png?dl=1', '가데이타다 들어가서 나중에 수정안했으면 좋겠네요...', 61),
	(64, 'https://www.dropbox.com/s/ofd6o278unpsv3g/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A83.png?dl=1', '이렇게 몇번을 더 써야할까요?', 61),
	(65, 'https://www.dropbox.com/s/rg3sgpebnnjsms3/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A84.png?dl=1', '하하하하아마아아아마암 졸리다', 63),
	(66, 'https://www.dropbox.com/s/ehpxa3uf79yxd63/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A87.png?dl=1', '빨리끝내자', 62),
	(67, 'https://www.dropbox.com/s/swup4xnvcxuwo3a/%EC%8B%A0%EB%8F%99%EA%B6%81%EA%B0%90%EC%9E%90%ED%83%95_%EC%84%A0%EB%A6%895.png?dl=1', '이십대때 아이락 스태디', 64),
	(68, 'https://www.dropbox.com/s/6sqrusz54qf1iwn/%EC%9E%90%EC%97%B0%EB%B3%84%EA%B3%A1_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B88.png?dl=1', '아아아아아아아아아앙', 65),
	(69, 'https://www.dropbox.com/s/52altukubct5tjv/%EC%A1%B0%EA%B0%9C%EC%8B%A0%ED%99%94_%EA%B0%80%EB%A1%9C%EC%88%98%EA%B8%B81.png?dl=1', 'yilhaela taewon', 66),
	(70, 'https://www.dropbox.com/s/rjvgl6p6beisrju/%EC%A1%B0%EA%B0%9C%EC%8B%A0%ED%99%94_%EA%B0%80%EB%A1%9C%EC%88%98%EA%B8%B810.png?dl=1', 'I have to stop djdjdjjdjd', 67),
	(71, 'https://www.dropbox.com/s/7h5d695phx3703h/%ED%9B%88%EB%82%A8%EB%8B%AD%EB%B0%9C_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B83.png?dl=1', 'three more weeks till it all ends', 68),
	(72, 'https://www.dropbox.com/s/iktk70rdfaaohlm/%ED%9B%88%EB%82%A8%EB%8B%AD%EB%B0%9C_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B88.png?dl=1', 'don’t ignore me ', 69),
	(73, 'https://www.dropbox.com/s/nmf0in1iau7ihbt/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A81.png?dl=1', 'late', 70),
	(74, 'https://www.dropbox.com/s/x42p9uckqk9wscc/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A83.png?dl=1', 'e and you are me', 71),
	(75, 'https://www.dropbox.com/s/w1r0z4v4sk68tzg/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A89.png?dl=1', 'ahahahahah', 72),
	(76, 'https://www.dropbox.com/s/2dig5c42ppkcuv6/%EC%9B%90%ED%82%A4%EC%B9%9C_%EC%84%9C%EC%B4%88_%EC%BB%A4%EB%A6%AC3.png?dl=1', 'sdkfjksjdfsdfjk?', 73),
	(77, 'https://www.dropbox.com/s/de0nrifhszabhos/%EB%9D%BC%EB%B6%80%EC%95%84%EB%9C%A8_%EC%95%95%EA%B5%AC%EC%A0%952.png?dl=1', '위이위잉 사이렌', 74),
	(78, 'https://www.dropbox.com/s/ulz9e752kvha8tr/%EB%A9%94%EC%A2%85%EB%93%9C%EB%A9%94%EB%A5%B4_%EC%84%9C%EC%B4%881.png?dl=1', '이츠 밑바닥', 75),
	(79, 'https://www.dropbox.com/s/89ywmgnvwc1t5am/%EB%A9%94%EC%A2%85%EB%93%9C%EB%A9%94%EB%A5%B4_%EC%84%9C%EC%B4%8811.png?dl=1', '몸농런아러니마얼', 76),
	(80, 'https://www.dropbox.com/s/2z3fnvqocbmk5ai/%EB%B2%84%ED%84%B0%ED%95%91%EA%B1%B0%ED%8C%AC%EC%BC%80%EC%9D%B4%ED%81%AC_%EA%B0%95%EB%82%A87.png?dl=1', 'ㄷ림팀', 77),
	(81, 'https://www.dropbox.com/s/ungm8zoj1gb185l/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A810.png?dl=1', 'that’s just how we roll m?', 78),
	(82, 'https://www.dropbox.com/s/4vjiy3sdplbum3y/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A813.png?dl=1', 'daslkdjflksj', 79),
	(83, 'https://www.dropbox.com/s/4vjiy3sdplbum3y/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A813.png?dl=1', 'LAST ONE WEEEEEEEE', 80),
	(84, 'https://www.dropbox.com/s/1g134mqn1g8mqg1/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A82.png?dl=1', '가데이타다 들어가서 나중에 수정안했으면 좋겠네요...', 81),
	(85, 'https://www.dropbox.com/s/ofd6o278unpsv3g/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A83.png?dl=1', '이렇게 몇번을 더 써야할까요?', 81),
	(86, 'https://www.dropbox.com/s/rg3sgpebnnjsms3/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A84.png?dl=1', '하하하하아마아아아마암 졸리다', 83),
	(87, 'https://www.dropbox.com/s/ehpxa3uf79yxd63/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A87.png?dl=1', '빨리끝내자', 82),
	(88, 'https://www.dropbox.com/s/swup4xnvcxuwo3a/%EC%8B%A0%EB%8F%99%EA%B6%81%EA%B0%90%EC%9E%90%ED%83%95_%EC%84%A0%EB%A6%895.png?dl=1', '이십대때 아이락 스태디', 84),
	(89, 'https://www.dropbox.com/s/6sqrusz54qf1iwn/%EC%9E%90%EC%97%B0%EB%B3%84%EA%B3%A1_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B88.png?dl=1', '아아아아아아아아아앙', 85),
	(90, 'https://www.dropbox.com/s/52altukubct5tjv/%EC%A1%B0%EA%B0%9C%EC%8B%A0%ED%99%94_%EA%B0%80%EB%A1%9C%EC%88%98%EA%B8%B81.png?dl=1', 'yilhaela taewon', 86),
	(91, 'https://www.dropbox.com/s/rjvgl6p6beisrju/%EC%A1%B0%EA%B0%9C%EC%8B%A0%ED%99%94_%EA%B0%80%EB%A1%9C%EC%88%98%EA%B8%B810.png?dl=1', 'I have to stop djdjdjjdjd', 87),
	(92, 'https://www.dropbox.com/s/7h5d695phx3703h/%ED%9B%88%EB%82%A8%EB%8B%AD%EB%B0%9C_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B83.png?dl=1', 'three more weeks till it all ends', 88),
	(93, 'https://www.dropbox.com/s/iktk70rdfaaohlm/%ED%9B%88%EB%82%A8%EB%8B%AD%EB%B0%9C_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B88.png?dl=1', 'don’t ignore me ', 89),
	(94, 'https://www.dropbox.com/s/nmf0in1iau7ihbt/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A81.png?dl=1', 'late', 90),
	(95, 'https://www.dropbox.com/s/x42p9uckqk9wscc/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A83.png?dl=1', 'i and you are me', 91),
	(96, 'https://www.dropbox.com/s/w1r0z4v4sk68tzg/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A89.png?dl=1', 'ahahahahah', 92),
	(97, 'https://www.dropbox.com/s/2dig5c42ppkcuv6/%EC%9B%90%ED%82%A4%EC%B9%9C_%EC%84%9C%EC%B4%88_%EC%BB%A4%EB%A6%AC3.png?dl=1', 'sdkfjksjdfsdfjk?', 93),
	(98, 'https://www.dropbox.com/s/de0nrifhszabhos/%EB%9D%BC%EB%B6%80%EC%95%84%EB%9C%A8_%EC%95%95%EA%B5%AC%EC%A0%952.png?dl=1', '위이위잉 사이렌', 94),
	(99, 'https://www.dropbox.com/s/ulz9e752kvha8tr/%EB%A9%94%EC%A2%85%EB%93%9C%EB%A9%94%EB%A5%B4_%EC%84%9C%EC%B4%881.png?dl=1', '이츠 밑바닥', 95),
	(100, 'https://www.dropbox.com/s/89ywmgnvwc1t5am/%EB%A9%94%EC%A2%85%EB%93%9C%EB%A9%94%EB%A5%B4_%EC%84%9C%EC%B4%8811.png?dl=1', '몸농런아러니마얼', 96),
	(101, 'https://www.dropbox.com/s/2z3fnvqocbmk5ai/%EB%B2%84%ED%84%B0%ED%95%91%EA%B1%B0%ED%8C%AC%EC%BC%80%EC%9D%B4%ED%81%AC_%EA%B0%95%EB%82%A87.png?dl=1', 'ㄷ림팀', 97),
	(102, 'https://www.dropbox.com/s/ungm8zoj1gb185l/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A810.png?dl=1', 'that’s just how we roll m?', 98),
	(103, 'https://www.dropbox.com/s/4vjiy3sdplbum3y/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A813.png?dl=1', 'daslkdjflksj', 99),
	(104, 'https://www.dropbox.com/s/4vjiy3sdplbum3y/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A813.png?dl=1', 'LAST ONE WEEEEEEEE', 100),
	(105, 'https://www.dropbox.com/s/1g134mqn1g8mqg1/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A82.png?dl=1', '가데이타다 들어가서 나중에 수정안했으면 좋겠네요...', 101),
	(106, 'https://www.dropbox.com/s/ofd6o278unpsv3g/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A83.png?dl=1', '이렇게 몇번을 더 써야할까요?', 101),
	(107, 'https://www.dropbox.com/s/rg3sgpebnnjsms3/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A84.png?dl=1', '하하하하아마아아아마암 졸리다', 103),
	(108, 'https://www.dropbox.com/s/ehpxa3uf79yxd63/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A87.png?dl=1', '빨리끝내자', 102),
	(109, 'https://www.dropbox.com/s/swup4xnvcxuwo3a/%EC%8B%A0%EB%8F%99%EA%B6%81%EA%B0%90%EC%9E%90%ED%83%95_%EC%84%A0%EB%A6%895.png?dl=1', '이십대때 아이락 스태디', 104),
	(110, 'https://www.dropbox.com/s/6sqrusz54qf1iwn/%EC%9E%90%EC%97%B0%EB%B3%84%EA%B3%A1_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B88.png?dl=1', '아아아아아아아아아앙', 105),
	(111, 'https://www.dropbox.com/s/52altukubct5tjv/%EC%A1%B0%EA%B0%9C%EC%8B%A0%ED%99%94_%EA%B0%80%EB%A1%9C%EC%88%98%EA%B8%B81.png?dl=1', 'yilhaela taewon', 106),
	(112, 'https://www.dropbox.com/s/rjvgl6p6beisrju/%EC%A1%B0%EA%B0%9C%EC%8B%A0%ED%99%94_%EA%B0%80%EB%A1%9C%EC%88%98%EA%B8%B810.png?dl=1', 'I have to stop djdjdjjdjd', 107),
	(113, 'https://www.dropbox.com/s/7h5d695phx3703h/%ED%9B%88%EB%82%A8%EB%8B%AD%EB%B0%9C_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B83.png?dl=1', 'three more weeks till it all ends', 108),
	(114, 'https://www.dropbox.com/s/iktk70rdfaaohlm/%ED%9B%88%EB%82%A8%EB%8B%AD%EB%B0%9C_%EC%A0%84%EA%B5%AD%EC%B2%B4%EC%9D%B88.png?dl=1', 'don’t ignore me ', 109),
	(115, 'https://www.dropbox.com/s/nmf0in1iau7ihbt/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A81.png?dl=1', 'late', 111),
	(116, 'https://www.dropbox.com/s/x42p9uckqk9wscc/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A83.png?dl=1', 'im meyou are me', 112),
	(117, 'https://www.dropbox.com/s/w1r0z4v4sk68tzg/%EB%8D%94%ED%95%98%EB%A1%B1%EB%B2%A0%EC%9D%B4_%EA%B0%95%EB%82%A8_%EB%B2%A0%ED%8A%B8%EB%82%A89.png?dl=1', 'ahahahahah', 113),
	(118, 'https://www.dropbox.com/s/2dig5c42ppkcuv6/%EC%9B%90%ED%82%A4%EC%B9%9C_%EC%84%9C%EC%B4%88_%EC%BB%A4%EB%A6%AC3.png?dl=1', 'sdkfjksjdfsdfjk?', 112),
	(119, 'https://www.dropbox.com/s/de0nrifhszabhos/%EB%9D%BC%EB%B6%80%EC%95%84%EB%9C%A8_%EC%95%95%EA%B5%AC%EC%A0%952.png?dl=1', '위이위잉 사이렌', 114),
	(120, 'https://www.dropbox.com/s/ulz9e752kvha8tr/%EB%A9%94%EC%A2%85%EB%93%9C%EB%A9%94%EB%A5%B4_%EC%84%9C%EC%B4%881.png?dl=1', '이츠 밑바닥', 115),
	(121, 'https://www.dropbox.com/s/89ywmgnvwc1t5am/%EB%A9%94%EC%A2%85%EB%93%9C%EB%A9%94%EB%A5%B4_%EC%84%9C%EC%B4%8811.png?dl=1', '몸농런아러니마얼', 116),
	(122, 'https://www.dropbox.com/s/2z3fnvqocbmk5ai/%EB%B2%84%ED%84%B0%ED%95%91%EA%B1%B0%ED%8C%AC%EC%BC%80%EC%9D%B4%ED%81%AC_%EA%B0%95%EB%82%A87.png?dl=1', 'ㄷ림팀', 117),
	(123, 'https://www.dropbox.com/s/ungm8zoj1gb185l/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A810.png?dl=1', 'that’s just how we roll m?', 118),
	(124, 'https://www.dropbox.com/s/4vjiy3sdplbum3y/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A813.png?dl=1', 'daslkdjflksj', 119),
	(125, 'https://www.dropbox.com/s/4vjiy3sdplbum3y/%ED%94%8C%EB%9D%BC%EC%9E%89%EC%8A%A4%EC%BD%98_%EA%B0%95%EB%82%A813.png?dl=1', 'LAST ONE WEEEEEEEE', 120),
	(126, 'https://www.dropbox.com/s/1g134mqn1g8mqg1/%EB%AC%B4%EC%9B%94%EC%8B%9D%ED%83%81_%EA%B0%95%EB%82%A82.png?dl=1', '가데이타다 들어가서 나중에 수정안했으면 좋겠네요...', 1);
/*!40000 ALTER TABLE `review_imagevo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.review_registrationvo
CREATE TABLE IF NOT EXISTS `review_registrationvo` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `advantages` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business_field_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cnt` bigint(20) DEFAULT NULL,
  `disadvantages` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `review_place` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `review_type_id` int(11) DEFAULT NULL,
  `theme_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `write_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `writer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`review_id`),
  KEY `FK1ihkebvswdjhsgc8gnkkq2625` (`user_id`),
  CONSTRAINT `FK1ihkebvswdjhsgc8gnkkq2625` FOREIGN KEY (`user_id`) REFERENCES `uservo` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table babbingdb.review_registrationvo: ~135 rows (approximately)
DELETE FROM `review_registrationvo`;
/*!40000 ALTER TABLE `review_registrationvo` DISABLE KEYS */;
INSERT INTO `review_registrationvo` (`review_id`, `advantages`, `business_field_id`, `cnt`, `disadvantages`, `modified_date`, `review_place`, `review_type_id`, `theme_id`, `title`, `write_date`, `writer`, `user_id`) VALUES
	(1, '장점을 적으라네요', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(2, '장점을 적으라네요', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(3, '장점을 적으라네요', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(4, '장점을 적으라네요귀찮죠', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(5, '장점을 적으라네요그래요', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(6, '장점을 적으라네요식별문자', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(7, '장점을 적으라네요인녕', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(8, '장점을 적으라네요가기싫다', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(9, '장점을 적으라네요배고파', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '외대앞', 1, 'chm', '메이크 외쿸 프랜즈', '2019-09-06 00:00:00', NULL, 3),
	(10, '장점을 적으라네요냠냠', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '경희대후문', 2, 'etc', '추억돋네요', '2019-09-06 00:00:00', NULL, 4),
	(11, '장점을 적으라네요두둗', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '자취방앞', 1, 'rnd', '내가 여기 단골이야!', '2019-09-06 00:00:00', NULL, 5),
	(12, '장점을 적으라네요', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(13, '장점을 적으라네요', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(14, '장점을 적으라네요귀찮죠', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(15, '장점을 적으라네요그래요', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(16, '장점을 적으라네요식별문자', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(17, '장점을 적으라네요인녕', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(18, '장점을 적으라네요가기싫다', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(19, '장점을 적으라네요배고파', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '외대앞', 1, 'chm', '메이크 외쿸 프랜즈', '2019-09-06 00:00:00', NULL, 3),
	(20, '장점을 적으라네요냠냠', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '경희대후문', 2, 'etc', '추억돋네요', '2019-09-06 00:00:00', NULL, 4),
	(21, '장점을 적으라네요두둗', 'jpn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '자취방앞', 1, 'rnd', '내가 여기 단골이야!', '2019-09-06 00:00:00', NULL, 5),
	(22, '장점을 적으라네요', 'kor', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(23, '장점을 적으라네요', 'kor', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(24, '장점을 적으라네요귀찮죠', 'kor', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(25, '장점을 적으라네요그래요', 'kor', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(26, '장점을 적으라네요식별문자', 'kor', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(27, '장점을 적으라네요인녕', 'kor', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(28, '장점을 적으라네요가기싫다', 'kor', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(29, '장점을 적으라네요배고파', 'kor', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '외대앞', 1, 'chm', '메이크 외쿸 프랜즈', '2019-09-06 00:00:00', NULL, 3),
	(30, '장점을 적으라네요냠냠', 'kor', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '경희대후문', 2, 'etc', '추억돋네요', '2019-09-06 00:00:00', NULL, 4),
	(31, '장점을 적으라네요두둗', 'kor', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '자취방앞', 1, 'rnd', '내가 여기 단골이야!', '2019-09-06 00:00:00', NULL, 5),
	(32, '장점을 적으라네요', 'wes', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(33, '장점을 적으라네요', 'wes', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(34, '장점을 적으라네요귀찮죠', 'wes', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(35, '장점을 적으라네요그래요', 'wes', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(36, '장점을 적으라네요식별문자', 'wes', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(37, '장점을 적으라네요인녕', 'wes', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(38, '장점을 적으라네요가기싫다', 'wes', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(39, '장점을 적으라네요배고파', 'wes', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '외대앞', 1, 'chm', '메이크 외쿸 프랜즈', '2019-09-06 00:00:00', NULL, 3),
	(40, '장점을 적으라네요냠냠', 'wes', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '경희대후문', 2, 'etc', '추억돋네요', '2019-09-06 00:00:00', NULL, 4),
	(41, '장점을 적으라네요두둗', 'wes', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '자취방앞', 1, 'rnd', '내가 여기 단골이야!', '2019-09-06 00:00:00', NULL, 5),
	(42, '장점을 적으라네요', 'chn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(43, '장점을 적으라네요', 'chn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(44, '장점을 적으라네요귀찮죠', 'chn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(45, '장점을 적으라네요그래요', 'chn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(46, '장점을 적으라네요식별문자', 'chn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(47, '장점을 적으라네요인녕', 'chn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(48, '장점을 적으라네요가기싫다', 'chn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(49, '장점을 적으라네요배고파', 'chn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '외대앞', 1, 'chm', '메이크 외쿸 프랜즈', '2019-09-06 00:00:00', NULL, 3),
	(50, '장점을 적으라네요냠냠', 'chn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '경희대후문', 2, 'etc', '추억돋네요', '2019-09-06 00:00:00', NULL, 4),
	(51, '장점을 적으라네요두둗', 'chn', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '자취방앞', 1, 'rnd', '내가 여기 단골이야!', '2019-09-06 00:00:00', NULL, 5),
	(52, '장점을 적으라네요', 'ind', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(53, '장점을 적으라네요', 'ind', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(54, '장점을 적으라네요귀찮죠', 'ind', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(55, '장점을 적으라네요그래요', 'ind', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(56, '장점을 적으라네요식별문자', 'ind', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(57, '장점을 적으라네요인녕', 'ind', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(58, '장점을 적으라네요가기싫다', 'ind', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(59, '장점을 적으라네요', 'sea', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(60, '장점을 적으라네요', 'sea', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(61, '장점을 적으라네요귀찮죠', 'sea', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(62, '장점을 적으라네요그래요', 'sea', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(63, '장점을 적으라네요식별문자', 'sea', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(64, '장점을 적으라네요인녕', 'sea', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(65, '장점을 적으라네요가기싫다', 'sea', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(66, '장점을 적으라네요', 'snk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(67, '장점을 적으라네요', 'snk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(68, '장점을 적으라네요귀찮죠', 'snk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(69, '장점을 적으라네요그래요', 'snk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(70, '장점을 적으라네요식별문자', 'snk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(71, '장점을 적으라네요인녕', 'snk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(72, '장점을 적으라네요가기싫다', 'snk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(73, '장점을 적으라네요', 'paz', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(74, '장점을 적으라네요', 'paz', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(75, '장점을 적으라네요귀찮죠', 'paz', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(76, '장점을 적으라네요그래요', 'paz', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(77, '장점을 적으라네요식별문자', 'paz', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(78, '장점을 적으라네요인녕', 'paz', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(79, '장점을 적으라네요가기싫다', 'paz', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(80, '장점을 적으라네요', 'chk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(81, '장점을 적으라네요', 'chk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(82, '장점을 적으라네요귀찮죠', 'chk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(83, '장점을 적으라네요그래요', 'chk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(84, '장점을 적으라네요식별문자', 'chk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(85, '장점을 적으라네요인녕', 'chk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(86, '장점을 적으라네요가기싫다', 'chk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(87, '장점을 적으라네요', 'fst', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(88, '장점을 적으라네요', 'fst', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(89, '장점을 적으라네요귀찮죠', 'fst', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(90, '장점을 적으라네요그래요', 'fst', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(91, '장점을 적으라네요식별문자', 'fst', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(92, '장점을 적으라네요인녕', 'fst', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(93, '장점을 적으라네요가기싫다', 'fst', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(94, '장점을 적으라네요', 'nsk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(95, '장점을 적으라네요', 'nsk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(96, '장점을 적으라네요귀찮죠', 'nsk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(97, '장점을 적으라네요그래요', 'nsk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(98, '장점을 적으라네요식별문자', 'nsk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(99, '장점을 적으라네요인녕', 'nsk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(100, '장점을 적으라네요가기싫다', 'nsk', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(101, '장점을 적으라네요', 'caf', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(102, '장점을 적으라네요', 'caf', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(103, '장점을 적으라네요귀찮죠', 'caf', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(104, '장점을 적으라네요그래요', 'caf', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(105, '장점을 적으라네요식별문자', 'caf', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(106, '장점을 적으라네요인녕', 'caf', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(107, '장점을 적으라네요가기싫다', 'caf', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(108, '장점을 적으라네요', 'pub', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(109, '장점을 적으라네요', 'pub', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(110, '장점을 적으라네요귀찮죠', 'pub', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(111, '장점을 적으라네요그래요', 'pub', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(112, '장점을 적으라네요식별문자', 'pub', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(113, '장점을 적으라네요인녕', 'pub', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(114, '장점을 적으라네요가기싫다', 'pub', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(115, '장점을 적으라네요', 'fus', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 1),
	(116, '장점을 적으라네요', 'fus', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(117, '장점을 적으라네요귀찮죠', 'fus', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 3),
	(118, '장점을 적으라네요그래요', 'fus', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(119, '장점을 적으라네요식별문자', 'fus', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(120, '장점을 적으라네요인녕', 'fus', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(121, '장점을 적으라네요가기싫다', 'fus', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(122, '장점을 적으라네요', 'etc', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '강남', 1, 'dte', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 5),
	(123, '장점을 적으라네요', 'etc', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '집근처', 2, 'dpt', '하늬돈까스! 강남주면에서 괜찮네요', '2019-09-06 00:00:00', NULL, 2),
	(124, '장점을 적으라네요귀찮죠', 'etc', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '노원평화도서실', 1, 'bth', '3000칼로리고마원요', '2019-09-06 00:00:00', NULL, 2),
	(125, '장점을 적으라네요그래요', 'etc', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '중계헬스', 1, 'tvr', '맘스터치에서 엄마의손맛이 느껴지네요', '2019-09-06 00:00:00', NULL, 4),
	(126, '장점을 적으라네요식별문자', 'etc', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '안산대', 1, 'dte', '하루종일 먹을수 있어요', '2019-09-06 00:00:00', NULL, 5),
	(127, '장점을 적으라네요인녕', 'etc', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '전곡앞', 2, 'bef', '같이외식했어요', '2019-09-06 00:00:00', NULL, 6),
	(128, '장점을 적으라네요가기싫다', 'etc', NULL, '단점은 너무많죠', '2019-09-06 00:00:00', '입대장소', 1, 'dte', '마지막 사회밥', '2019-09-06 00:00:00', NULL, 1),
	(129, NULL, 'kor', NULL, NULL, '2019-09-12 00:00:00', '노원이에요', NULL, NULL, '임시데이터', '2019-09-12 00:00:00', NULL, 1),
	(130, NULL, 'kor', NULL, NULL, '2019-09-12 18:37:58', '노원이에요', NULL, NULL, '임시데이터', '2019-09-12 18:37:58', NULL, 1),
	(131, NULL, 'kor', NULL, NULL, '2019-09-12 18:38:25', '노원이에요', NULL, NULL, '임시데이터', '2019-09-12 18:38:25', NULL, 1),
	(132, NULL, 'kor', NULL, NULL, '2019-09-12 18:38:37', '노원이에요', NULL, NULL, '임시데이터', '2019-09-12 18:38:37', NULL, 1),
	(133, NULL, 'kor', NULL, NULL, '2019-09-12 18:38:43', '노원이에요', NULL, NULL, '임시데이터', '2019-09-12 18:38:43', NULL, 1),
	(134, NULL, 'kor', NULL, NULL, '2019-09-12 18:38:47', '노원이에요', NULL, NULL, '임시데이터', '2019-09-12 18:38:47', NULL, 1),
	(136, 'd', NULL, NULL, 'd', '2019-09-20 13:23:06', NULL, NULL, NULL, 'chicken', '2019-09-20 13:23:06', NULL, 10);
/*!40000 ALTER TABLE `review_registrationvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.review_typevo
CREATE TABLE IF NOT EXISTS `review_typevo` (
  `review_type_id` int(11) NOT NULL,
  `review_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`review_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table babbingdb.review_typevo: ~2 rows (approximately)
DELETE FROM `review_typevo`;
/*!40000 ALTER TABLE `review_typevo` DISABLE KEYS */;
INSERT INTO `review_typevo` (`review_type_id`, `review_type`) VALUES
	(1, '일반'),
	(2, '기업');
/*!40000 ALTER TABLE `review_typevo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.scrapvo
CREATE TABLE IF NOT EXISTS `scrapvo` (
  `scrap_id` int(11) NOT NULL AUTO_INCREMENT,
  `review_id` int(11) NOT NULL,
  `scrap_time` datetime DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`scrap_id`)
) ENGINE=InnoDB AUTO_INCREMENT=224 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table babbingdb.scrapvo: ~49 rows (approximately)
DELETE FROM `scrapvo`;
/*!40000 ALTER TABLE `scrapvo` DISABLE KEYS */;
INSERT INTO `scrapvo` (`scrap_id`, `review_id`, `scrap_time`, `username`) VALUES
	(14, 14, NULL, 'tonyzorz'),
	(15, 32, NULL, 'tonyzorz'),
	(16, 89, NULL, 'tonyzorz'),
	(29, 1, NULL, 'tonyzorz'),
	(58, 44, NULL, 'tonyzorz'),
	(61, 68, NULL, 'tonyzorz'),
	(68, 5, NULL, 'tonyzorz'),
	(87, 23, NULL, 'tonyzorz'),
	(90, 27, NULL, 'tonyzorz'),
	(96, 25, NULL, 'tonyzorz'),
	(97, 45, NULL, 'tonyzorz'),
	(98, 43, NULL, 'tonyzorz'),
	(99, 48, NULL, 'tonyzorz'),
	(101, 15, NULL, 'tonyzorz'),
	(103, 80, NULL, 'tonyzorz'),
	(104, 106, NULL, 'tonyzorz'),
	(105, 63, NULL, 'jinkwang'),
	(106, 99, NULL, 'jinkwang'),
	(107, 42, NULL, 'jinkwang'),
	(108, 24, NULL, 'tonyzorz'),
	(110, 49, NULL, 'tonyzorz'),
	(111, 34, NULL, 'tonyzorz'),
	(112, 39, NULL, 'tonyzorz'),
	(113, 9, NULL, 'tonyzorz'),
	(114, 77, NULL, 'tonyzorz'),
	(115, 57, NULL, 'tonyzorz'),
	(124, 88, NULL, 'tonyzorz'),
	(125, 109, NULL, 'tonyzorz'),
	(126, 33, NULL, 'tonyzorz'),
	(127, 3, NULL, 'tonyzorz'),
	(130, 73, NULL, 'improve'),
	(136, 17, NULL, 'improve'),
	(139, 100, NULL, 'improve'),
	(140, 92, NULL, 'improve'),
	(141, 9, NULL, 'improve'),
	(143, 24, NULL, 'improve'),
	(144, 31, NULL, 'improve'),
	(146, 106, NULL, 'improve'),
	(147, 21, NULL, 'improve'),
	(152, 13, NULL, 'improve'),
	(182, 48, NULL, 'improve'),
	(191, 3, NULL, 'improve'),
	(192, 2, NULL, 'improve'),
	(203, 29, NULL, 'improve'),
	(209, 53, NULL, 'improve'),
	(210, 70, NULL, 'improve'),
	(212, 87, NULL, 'improve'),
	(213, 59, NULL, 'improve'),
	(214, 79, NULL, 'improve');
/*!40000 ALTER TABLE `scrapvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.tagvo
CREATE TABLE IF NOT EXISTS `tagvo` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `img_id` int(11) DEFAULT NULL,
  `tag_content` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tagx` int(11) NOT NULL,
  `tagy` int(11) NOT NULL,
  PRIMARY KEY (`tag_id`),
  KEY `FK28s642mwer6l1u13ef7157rsf` (`img_id`),
  CONSTRAINT `FK28s642mwer6l1u13ef7157rsf` FOREIGN KEY (`img_id`) REFERENCES `review_imagevo` (`img_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table babbingdb.tagvo: ~0 rows (approximately)
DELETE FROM `tagvo`;
/*!40000 ALTER TABLE `tagvo` DISABLE KEYS */;
/*!40000 ALTER TABLE `tagvo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.themevo
CREATE TABLE IF NOT EXISTS `themevo` (
  `theme_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `theme_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`theme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table babbingdb.themevo: ~14 rows (approximately)
DELETE FROM `themevo`;
/*!40000 ALTER TABLE `themevo` DISABLE KEYS */;
INSERT INTO `themevo` (`theme_id`, `theme_name`) VALUES
	('bef', '소고기'),
	('bth', '생일'),
	('chm', '닭고기'),
	('dpt', '회식'),
	('dte', '데이트'),
	('eff', '가성비'),
	('etc', '기타'),
	('fmt', '가족모임'),
	('foc', '돼지고기'),
	('inm', '소개팅'),
	('rnd', '비오는날'),
	('sgm', '혼밥'),
	('spc', '이색요리'),
	('tvr', 'tv맛집');
/*!40000 ALTER TABLE `themevo` ENABLE KEYS */;

-- Dumping structure for table babbingdb.uservo
CREATE TABLE IF NOT EXISTS `uservo` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_count` int(11) DEFAULT NULL,
  `favor_factor` int(11) DEFAULT NULL,
  `following_count` int(11) DEFAULT NULL,
  `introduce` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_count` int(11) DEFAULT NULL,
  `profile_img` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'https://www.dropbox.com/s/do02wrbglujwmxo/Bobbing-main-Circle-member.gif?dl=1',
  `put_count` int(11) DEFAULT NULL,
  `role` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `scrap_factor` int(11) DEFAULT NULL,
  `sns_factor` int(11) DEFAULT NULL,
  `total_count` int(11) DEFAULT NULL,
  `u_rank_img1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `u_rank_img2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `u_rank_img3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `u_rank_img4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `u_rank_img5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_score` double DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table babbingdb.uservo: ~10 rows (approximately)
DELETE FROM `uservo`;
/*!40000 ALTER TABLE `uservo` DISABLE KEYS */;
INSERT INTO `uservo` (`user_id`, `comment_count`, `favor_factor`, `following_count`, `introduce`, `nickname`, `password`, `post_count`, `profile_img`, `put_count`, `role`, `scrap_factor`, `sns_factor`, `total_count`, `u_rank_img1`, `u_rank_img2`, `u_rank_img3`, `u_rank_img4`, `u_rank_img5`, `user_email`, `user_key`, `user_score`) VALUES
	(1, 1, 1, 4, NULL, 'tonyzorz', 'tonyzorz', 1, 'https://www.dropbox.com/s/do02wrbglujwmxo/Bobbing-main-Circle-member.gif?dl=1', 0, NULL, 8, 0, 1, NULL, NULL, NULL, NULL, NULL, 'tonyzorz@naver.com', NULL, 1),
	(2, 2, 2, 4, NULL, 'taewon', 'taewon', 2, 'https://www.dropbox.com/s/do02wrbglujwmxo/Bobbing-main-Circle-member.gif?dl=1', 0, NULL, 6, 0, 2, NULL, NULL, NULL, NULL, NULL, 'taewon@naver.com', NULL, 2),
	(3, 3, 3, 3, NULL, 'jinkwang', 'jinkwang', 3, 'https://www.dropbox.com/s/do02wrbglujwmxo/Bobbing-main-Circle-member.gif?dl=1', 0, NULL, 13, 0, 3, NULL, NULL, NULL, NULL, NULL, 'jinkwang@naver.com', NULL, 3),
	(4, 4, 4, 4, NULL, 'bumhong', 'bumhong', 4, 'https://www.dropbox.com/s/do02wrbglujwmxo/Bobbing-main-Circle-member.gif?dl=1', 0, NULL, 3, 0, 4, NULL, NULL, NULL, NULL, NULL, 'bumhong@naver.com', NULL, 4),
	(5, 5, 5, 3, NULL, 'sungha', 'sungha', 5, 'https://www.dropbox.com/s/do02wrbglujwmxo/Bobbing-main-Circle-member.gif?dl=1', 0, NULL, 5, 0, 5, NULL, NULL, NULL, NULL, NULL, 'sungha@naver.com', NULL, 5),
	(6, 6, 6, 3, NULL, 'ujin', 'ujin', 6, 'https://www.dropbox.com/s/do02wrbglujwmxo/Bobbing-main-Circle-member.gif?dl=1', 0, NULL, 5, 0, 6, NULL, NULL, NULL, NULL, NULL, 'ujin@naver.com', NULL, 6),
	(7, 7, 7, 3, NULL, 'tonyzorzzz', 'tonyzorzzz', 7, 'https://www.dropbox.com/s/do02wrbglujwmxo/Bobbing-main-Circle-member.gif?dl=1', 0, NULL, 0, 0, 7, NULL, NULL, NULL, NULL, NULL, 'tonyzorzzz@naver.com', NULL, 7),
	(10, 0, 0, 1, NULL, 'improve', '615ed7fb1504b0c724a296d7a69e6c7b2f9ea2c57c1d8206c5afdf392ebdfd25', 0, 'https://www.dropbox.com/s/do02wrbglujwmxo/Bobbing-main-Circle-member.gif?dl=1', 0, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 'tonyzorz951@naver.com', 'Y', 0),
	(23, NULL, NULL, NULL, NULL, 'yuju', '28f0116ef42bf718324946f13d787a1d41274a08335d52ee833d5b577f02a32a', NULL, 'https://www.dropbox.com/s/do02wrbglujwmxo/Bobbing-main-Circle-member.gif?dl=1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'kbh7289@naver.com', 'JKM8DQB0Vk7qoQmR9Kmv', NULL),
	(24, NULL, NULL, NULL, NULL, 'samurai', '15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225', NULL, 'https://www.dropbox.com/s/do02wrbglujwmxo/Bobbing-main-Circle-member.gif?dl=1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'kjk0656@naver.com', 'Y', NULL);
/*!40000 ALTER TABLE `uservo` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
