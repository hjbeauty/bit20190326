package com.fashionlog.model.service;


public interface RankingService {
	
	public void setBrandCount();
	
	public void setLikesCount();
}
