package com.fashionlog.model.service;

public interface SocialService {

}
