package com.fashionlog.model.dto;


public interface SocialEvent {

}
