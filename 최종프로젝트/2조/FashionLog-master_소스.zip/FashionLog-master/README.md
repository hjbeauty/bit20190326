
# FashionLog
FashionLog is awesome SNS for the fashion people

## Logo
![FashionLog Logo](./intro_sources/FashionLog_Logo.png)

## Story Board
[FashionLog Storyboard(google docs)](https://docs.google.com/presentation/d/1nlmemBC-Cr-CHZzxUBwT3X9AjotvQ8nLj7ztR-WunUg/edit?usp=sharing)

## UML

### class diagram
[FashionLog Class Diagram(drawio)](https://drive.google.com/file/d/1D6zVhJm32IYNzrDsjjai0qM1iqiTXHOA/view?usp=sharing)

### ERD
![FashionLog ERD](./intro_sources/FashionLog_ERD.png)
