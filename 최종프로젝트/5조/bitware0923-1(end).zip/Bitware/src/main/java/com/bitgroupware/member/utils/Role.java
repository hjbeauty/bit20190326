package com.bitgroupware.member.utils;

public enum Role {

	ROLE_ADMIN, ROLE_USER, ROLE_PL, ROLE_PM
	
}
