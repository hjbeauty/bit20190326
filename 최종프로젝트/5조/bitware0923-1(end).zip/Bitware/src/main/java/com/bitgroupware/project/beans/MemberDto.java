package com.bitgroupware.project.beans;

import lombok.Data;

@Data
public class MemberDto {
	
	private int memNo;
	private String memId;
	private String memName;
	private String deptName;
	private String teamName;
	private String ranks;
	
}
