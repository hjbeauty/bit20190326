package com.bitgroupware.community.utils;

import java.util.HashMap;
import java.util.Map;

public class TemporaryFileUrl {

	public static Map<String,String> fileUrl = new HashMap<String,String>();
}
