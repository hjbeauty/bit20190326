package com.bitgroupware.chat.utils;

public class TemporaryInteger {

	public static int counting;
	
}
