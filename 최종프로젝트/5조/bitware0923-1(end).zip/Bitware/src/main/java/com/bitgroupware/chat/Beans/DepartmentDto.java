package com.bitgroupware.chat.Beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DepartmentDto {

	private int deptNo;
	private String deptName;
}
