package com.bitgroupware.chat.utils;

import java.util.HashMap;
import java.util.Map;

public class TemporaryMap {

	public static Map<String,String> checkPersonMap = new HashMap<String,String>();
}
