package com.bitgroupware.project.beans;

import lombok.Data;

@Data
public class ProjectMembersDto {
	private int prjMemNo;
	private int prjCode;
	private String memId;
	
}
