package beans;

public class MemberDto {
	private String userName;
	private String id;
	private String pw;
	private String Email;
	private String birth;
	public MemberDto() {
		// TODO Auto-generated constructor stub
	}
	
	public MemberDto(String userName, String id, String pw, String email, String birth) {
		super();
		this.userName = userName;
		this.id = id;
		this.pw = pw;
		this.Email = email;
		this.birth = birth;
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	
	
}