package beans;

import java.sql.Date;

public class BoardDto {
	private int no;
	private String title;
	private String writer;
	private Date wtdate;
	private String contents;
	public BoardDto() {
		// TODO Auto-generated constructor stub
	}
	public BoardDto(int no, String title, String writer, Date wtdate, String contents) {
		super();
		this.no = no;
		this.title = title;
		this.writer = writer;
		this.wtdate = wtdate;
		this.contents = contents;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public Date getWtdate() {
		return wtdate;
	}
	public void setWtdate(Date wtdate) {
		this.wtdate = wtdate;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	
}
