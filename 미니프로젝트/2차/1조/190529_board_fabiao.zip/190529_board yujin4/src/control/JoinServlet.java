package control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Dao;

public class JoinServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
	
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String userName = request.getParameter("userName");
		String email = request.getParameter("email");
		String birth = request.getParameter("birth");
		
		String idCkResult = Dao.instance.idCheck(id);
		
		if (idCkResult != "0") {
			request.setAttribute("msg","�̹� �����ϴ� ���̵� �Դϴ�.");
			request.getRequestDispatcher("joinForm.jsp").forward(request, response);
			
		} else {
			Dao.instance.insertUserInfo(userName, id, pw, email, birth);
			request.setAttribute("msg","ȸ�������� ���ϵ帳�ϴ�. �ٽ� �α����� ���ּ���.");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		
		
	}

}
