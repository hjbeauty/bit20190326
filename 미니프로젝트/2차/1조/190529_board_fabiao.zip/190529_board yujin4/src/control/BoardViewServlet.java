package control;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.BoardDto;
import model.Dao;

public class BoardViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");

		String no = request.getParameter("viewNo");

		BoardDto boardView = Dao.instance.boardView(no);

		HttpSession session = request.getSession();
		String writer = (String)session.getAttribute("sessionId");

		String mineYN = "";
		if (writer.equals(boardView.getWriter())) {
			mineYN = "Y";
		} else {
			mineYN = "N";
		}
		
		
		request.setAttribute("boardView", boardView);
		request.setAttribute("mineYN", mineYN);
		request.getRequestDispatcher("views/postForm.jsp").forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");

		String no = request.getParameter("viewNo");

		BoardDto boardView = Dao.instance.boardView(no);

		HttpSession session = request.getSession();
		String writer = (String)session.getAttribute("sessionId");

		String mineYN = "";
		if (writer.equals(boardView.getWriter())) {
			mineYN = "Y";
		} else {
			mineYN = "N";
		}
		
		
		request.setAttribute("boardView", boardView);
		request.setAttribute("mineYN", mineYN);
		request.getRequestDispatcher("views/postForm.jsp").forward(request, response);
	}
}