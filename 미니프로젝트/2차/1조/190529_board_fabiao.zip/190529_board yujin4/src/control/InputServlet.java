package control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class InputServlet
 */
public class InputServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		
		if (session.getAttribute("sessionId") != null) {
			System.out.println("��ǲ");
			
			String sessionId = (String)session.getAttribute("sessionId");
			request.setAttribute("sessionId", sessionId);
			
			System.out.println(session.getAttribute("sessionId"));

			request.getRequestDispatcher("views/inputForm.jsp").forward(request, response);
			
		} else {
			PrintWriter out = response.getWriter();
			out.println("<script>alert('������ ����Ǿ����ϴ�. �ٽ� �α����ϼ���.'); location.href='index.jsp';</script>");
			out.flush();
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		
		if (session.getAttribute("sessionId") != null) {
			System.out.println("��ǲ");
			
			String sessionId = (String)session.getAttribute("sessionId");
			request.setAttribute("sessionId", sessionId);
			
			System.out.println(session.getAttribute("sessionId"));
			
			String title = request.getParameter("title1");
			String no = request.getParameter("no1");
			System.out.println(title + " ����");
			System.out.println(no + " ��ȣ");
			
			request.setAttribute("title", title);
			request.setAttribute("no", no);
			
			
			request.getRequestDispatcher("views/replyForm.jsp").forward(request, response);
			
		} else {
			PrintWriter out = response.getWriter();
			out.println("<script>alert('������ ����Ǿ����ϴ�. �ٽ� �α����ϼ���.'); location.href='index.jsp';</script>");
			out.flush();
		}
	}

}
