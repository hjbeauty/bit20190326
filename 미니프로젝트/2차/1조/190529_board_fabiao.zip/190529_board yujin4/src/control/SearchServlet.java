package control;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.BoardDto;
import model.Dao;

/**
 * Servlet implementation class SearchServlet
 */
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		String select = request.getParameter("searchSelect");
		String search = request.getParameter("search");
		System.out.println("1"+select);
		System.out.println("2"+search);
		
		
		List<BoardDto> boardList = null;
		
		if (select.equals("title")) {
			boardList = Dao.instance.titleSerch(search);
		}else if(select.equals("writer")){
			boardList = Dao.instance.writerSerch(search);
		}else{
			boardList = Dao.instance.bothSerch(search);
		}
		
		request.setAttribute("boardList", boardList);
		request.getRequestDispatcher("views/boardForm.jsp").forward(request, response);
	}

}
