package control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.BoardDto;
import model.Dao;

/**
 * Servlet implementation class boardDeleteServlet
 */
public class BoardDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		
		int no = Integer.parseInt(String.valueOf(request.getParameter("viewNo")));
		String writer = (String)session.getAttribute("sessionId");
		
		BoardDto boardDto = new BoardDto();
		boardDto.setNo(no);
		boardDto.setWriter(writer);
		
		Dao.instance.deleteBoard(boardDto);
			
		response.sendRedirect("BoardListServlet"); 
//		request.getRequestDispatcher("BoardListServlet").forward(request, response);
	
	}

}