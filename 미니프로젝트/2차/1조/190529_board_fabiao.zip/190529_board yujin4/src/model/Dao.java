package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.BoardDto;

public class Dao {
	static private Connection conn;
	private PreparedStatement pStmt;
	private ResultSet result;

	static public Connection  getConn() {
		return conn;
	}

	static public Dao instance=new Dao();

	static public Dao getInstance() {

		return instance;

	}

	private Dao() {

		connection();

	}
	private void connection() {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://192.168.0.52:3306/board?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
			//			String url = "jdbc:mysql://localhost:3306/board?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
			conn = DriverManager.getConnection(url,"test","1234");
			//			conn = DriverManager.getConnection(url,"root","1234");
			//			System.out.println("�솕�굹�슂");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void insertUserInfo(String username, String id, String pw, String email, String birth) {
		String sql = "INSERT INTO BOARD.MEMBER VALUES(?, ?, ?, ?, ?)";
		try {
			pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, username);
			pStmt.setString(2, id);
			pStmt.setString(3, pw);
			pStmt.setString(4, email);
			pStmt.setString(5, birth);
			pStmt.executeUpdate();
		} catch (SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}

	public boolean loginIdCheck(String id, String pw) {
		String sql = "SELECT PW FROM BOARD.MEMBER WHERE ID = ?";
		try {
			pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, id);
			result = pStmt.executeQuery();
			if (result.next()) {
				if (result.getString(1).equals(pw)) {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public void insertBoard(String writer, String title, String contents) {

		String sql = "INSERT INTO BOARD.BOARD (title, writer, contents, wtdate) VALUES(?, ?, ?, sysdate())";
		try {
			pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, writer);
			pStmt.setString(2, title);
			pStmt.setString(3, contents);
			pStmt.executeUpdate();
		} catch (SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}


	public String idCheck(String id) { 
		// select count(userId) from member where userId=`占쏙옙占쏙옙占쏙옙韜째占� 
		String sql = "SELECT COUNT(ID) FROM BOARD.MEMBER WHERE ID=?";
		try { 
			pStmt = conn.prepareStatement(sql); 
			pStmt.setString(1, id); 
			result = pStmt.executeQuery(); 
			if(result.next()) {
				if (result.getInt(1) == 1) { 

					return "1"; 
				} 
			}
		} catch(SQLException e) { 
			e.printStackTrace(); 
		} return "0"; 
	}

	//占쌉쏙옙占쏙옙 占쏙옙占쏙옙트占쏙옙占�
	public List<BoardDto> boardList() { 
		// select count(userId) from member where userId=`占쏙옙占쏙옙占쏙옙韜째占� 
		String sql = "SELECT no, title, writer, wtdate FROM BOARD.BOARD order by no desc";

		List<BoardDto> bbs = new ArrayList<BoardDto>();

		try { 
			pStmt = conn.prepareStatement(sql); 
			result = pStmt.executeQuery(); 
			while(result.next()) {
				BoardDto dto = new BoardDto();
				dto.setNo(result.getInt(("no")));
				dto.setTitle(result.getString(("title")));
				dto.setWriter(result.getString("writer"));
				dto.setWtdate(result.getDate(("wtdate")));
				bbs.add(dto);
			}
		} catch(SQLException e) { 
			e.printStackTrace(); 
		} 
		return bbs; 
	}

	//
	public BoardDto boardView(String no) { 
		// select count(userId) from member where userId=`占쏙옙占쏙옙占쏙옙韜째占� 
		String sql = "SELECT no, writer, title, wtdate, contents FROM BOARD.BOARD WHERE no = ?";

		BoardDto dto = new BoardDto();

		try { 
			pStmt = conn.prepareStatement(sql); 
			pStmt.setString(1, no); 
			result = pStmt.executeQuery();
			while(result.next()) {
				dto.setNo(result.getInt(("no")));
				dto.setWriter(result.getString("writer"));
				dto.setTitle(result.getString(("title")));
				dto.setWtdate(result.getDate(("wtdate")));
				dto.setContents(result.getString(("contents")));
			}
		} catch(SQLException e) { 
			e.printStackTrace(); 
		} 
		return dto; 
	}

	public BoardDto boardViewMine(String no, String writer) { 
		// select count(userId) from member where userId=`챦쩔쩍챦쩔쩍챦쩔쩍챦쩔쩍챦쩔쩍챦쩔쩍횚쨌횂째챦쩔쩍 
		String sql = "SELECT no, writer, title, wtdate, contents FROM BOARD.BOARD WHERE no = ? AND writer = ?";

		BoardDto dto = new BoardDto();

		try { 
			pStmt = conn.prepareStatement(sql); 
			pStmt.setString(1, no); 
			pStmt.setString(2, writer); 
			result = pStmt.executeQuery();
			while(result.next()) {
				dto.setNo(result.getInt(("no")));
				dto.setWriter(result.getString("writer"));
				dto.setTitle(result.getString(("title")));
				dto.setWtdate(result.getDate(("wtdate")));
				dto.setContents(result.getString(("contents")));
			}
		} catch(SQLException e) { 
			e.printStackTrace(); 
		} 
		return dto; 
	}


	public List<BoardDto> titleSerch(String search) { 
		// select count(userId) from member where userId=`占쏙옙占쏙옙占쏙옙韜째占� 
		String sql = "SELECT no, writer, title, wtdate, contents FROM BOARD.BOARD WHERE title LIKE ?";

		List<BoardDto> bbs = new ArrayList<BoardDto>();

		try { 
			pStmt = conn.prepareStatement(sql); 
			pStmt.setString(1, "%" + search + "%");
			result = pStmt.executeQuery(); 
			while(result.next()) {
				BoardDto dto = new BoardDto();
				dto.setNo(result.getInt(("no")));
				dto.setTitle(result.getString(("title")));
				dto.setWriter(result.getString("writer"));
				dto.setWtdate(result.getDate(("wtdate")));
				bbs.add(dto);
			}
		} catch(SQLException e) { 
			e.printStackTrace(); 
		} 
		return bbs; 
	}

	public List<BoardDto> writerSerch(String search) { 
		// select count(userId) from member where userId=`占쏙옙占쏙옙占쏙옙韜째占� 
		String sql = "SELECT no, writer, title, wtdate, contents FROM BOARD.BOARD WHERE writer LIKE ?";

		List<BoardDto> bbs = new ArrayList<BoardDto>();

		try { 
			pStmt = conn.prepareStatement(sql); 
			pStmt.setString(1, "%" + search + "%");
			result = pStmt.executeQuery(); 
			while(result.next()) {
				BoardDto dto = new BoardDto();
				dto.setNo(result.getInt(("no")));
				dto.setTitle(result.getString(("title")));
				dto.setWriter(result.getString("writer"));
				dto.setWtdate(result.getDate(("wtdate")));
				bbs.add(dto);
			}
		} catch(SQLException e) { 
			e.printStackTrace(); 
		} 
		return bbs; 
	}

	public List<BoardDto> bothSerch(String search) { 
		// select count(userId) from member where userId=`占쏙옙占쏙옙占쏙옙韜째占� 
		String sql = "SELECT no, writer, title, wtdate, contents FROM BOARD.BOARD WHERE (title LIKE ?) OR (writer LIKE ?)";

		List<BoardDto> bbs = new ArrayList<BoardDto>();

		try { 
			pStmt = conn.prepareStatement(sql); 
			pStmt.setString(1, "%" + search + "%");
			pStmt.setString(2, "%" + search + "%");
			result = pStmt.executeQuery(); 
			while(result.next()) {
				BoardDto dto = new BoardDto();
				dto.setNo(result.getInt(("no")));
				dto.setTitle(result.getString(("title")));
				dto.setWriter(result.getString("writer"));
				dto.setWtdate(result.getDate(("wtdate")));
				bbs.add(dto);
			}
		} catch(SQLException e) { 
			e.printStackTrace(); 
		} 
		return bbs; 
	}

	public void deleteBoard(BoardDto boardDto) {
		String sql = "DELETE FROM BOARD.BOARD WHERE NO=?";
		try {
			pStmt = conn.prepareStatement(sql);
			pStmt.setInt(1, boardDto.getNo());
			pStmt.executeUpdate();
		} catch (SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}

	public void updateBoard(BoardDto boardDto) {
		String sql = "UPDATE BOARD.BOARD SET title = ?, contents = ? WHERE no = ? AND writer = ?";
		try {
			pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, boardDto.getTitle());
			pStmt.setString(2, boardDto.getContents());
			pStmt.setInt(3, boardDto.getNo());
			pStmt.setString(4, boardDto.getWriter());
			pStmt.executeUpdate();
		} catch (SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}

	}

	public void reply(String title, String writer, String content, String re_Group, String re_seq, String re_lev) {

		try {
			connection();
			System.out.println("--reply connection");

			String sql = "insert into board (title, writer, wtDate, content, re_Group, re_seq, re_lev) values (?, ?, sysdate(), ?, ?, ?, ?)";
			pStmt = conn.prepareStatement(sql);

			pStmt.setString(1, title);
			pStmt.setString(2, writer);
			pStmt.setString(3, content);
			pStmt.setInt(4, Integer.parseInt(re_Group));
			pStmt.setInt(5, Integer.parseInt(re_seq) + 1);
			pStmt.setInt(6, Integer.parseInt(re_lev) + 1);

			pStmt.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("!!!!!!!reply error!!!!!!!");
			e.printStackTrace();
		}
	}
}