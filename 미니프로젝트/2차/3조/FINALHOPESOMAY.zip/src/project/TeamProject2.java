package project;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowSorter;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import java.sql.*;

public class TeamProject2 extends JFrame {
	private JPanel contentPane;
	private JTextField stdNumbField;
	private JTextField nameField;
	private JTextField korField;
	private JTextField engField;
	private JTextField mathField;
	private JLabel label5;
	private JTextField socField;
	private JTextField sciField;
	private static JTable table;
	private DefaultTableModel model;

	private Object[][] data;
	private String colnames[] = { "학번", "이름", "국어", "영어", "수학", "한국지리", "세계지리", "경제지리", "국사", "세계사", "근현대사", "물리", "화학",
			"생물", "지구과학", "총점", "평균", "등급" };

	private Connection conn;
	private PreparedStatement pStmt;
	private ResultSet result;


	JButton avgList;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TeamProject2 frame = new TeamProject2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public TeamProject2() {
		projectLayout();
		btnFunction();
		accDb();
	}

	private void accDb() {

		try {
			Class.forName("org.h2.Driver");
			conn = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
			System.out.println("DB접속 완료");
			pStmt = conn.prepareStatement(
					"select studentgrade.studentid, name, korean, english, math, koreageo, worldgeo, economicgeo, history, worldhistory, modernhistory, physics, chemistry, livingscience, geoscience, totalScore, avg, rank from studentrecord,studentgrade where studentrecord.studentid=studentgrade.studentid");
			result = pStmt.executeQuery();

			while (result.next()) {
				String studentid = result.getString("StudentID");
				String name = result.getString("name");
				int korean = result.getInt("Korean");
				int english = result.getInt("English");
				int math = result.getInt("Math");
				int koreaGeo = result.getInt("KoreaGeo");
				int worldGeo = result.getInt("WorldGeo");
				int economicGeo = result.getInt("EconomicGeo");
				int history = result.getInt("History");
				int worldHistory = result.getInt("WorldHistory");
				int modernHistory = result.getInt("ModernHistory");
				int physics = result.getInt("Physics");
				int chemistry = result.getInt("Chemistry");
				int livingScience = result.getInt("LivingScience");
				int geoscience = result.getInt("Geoscience");
				int totalScore = result.getInt("totalScore");
				double avg = result.getDouble("avg");
				int rank = result.getInt("rank");
				Object data[] = { studentid, name, korean, english, math, koreaGeo, worldGeo, economicGeo, history,
						worldHistory, modernHistory, physics, chemistry, livingScience, geoscience, totalScore, avg, rank };
				model.addRow(data); // 자료를 model에 넘겨주고 model을 통해 table에 표현
			}

		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "accDb err : " + e); // 알림창으로 에러 출력

		} finally { // 작업이 끝나면 닫아주어야 한다
			try {
				if (result != null)
					result.close();
				if (pStmt != null)
					pStmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				// TODO: handle exception

			}
		}
	}

	public void projectLayout() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		}
		setResizable(false);
		setTitle("\uC131\uC801\uC785\uB825\uAE30");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		model = new DefaultTableModel(data, colnames);
		table = new JTable(model);
		table.setEnabled(false);
		RowSorter<TableModel> sorter = new TableRowSorter<TableModel>(model);
		table.setRowSorter(sorter);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setEnabled(false);
		scrollPane.setBounds(12, 50, 1050, 411);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);
		JLabel label1 = new JLabel("학번");
		label1.setFont(new Font("굴림", Font.BOLD, 16));
		label1.setBounds(12, 10, 40, 30);
		contentPane.add(label1);
		JLabel label2 = new JLabel("이름");
		label2.setFont(new Font("굴림", Font.BOLD, 16));
		label2.setBounds(136, 10, 40, 30);
		contentPane.add(label2);
		JLabel label3 = new JLabel("국어");
		label3.setFont(new Font("굴림", Font.BOLD, 16));
		label3.setBounds(248, 8, 40, 30);
		contentPane.add(label3);
		JLabel label4 = new JLabel("영어");
		label4.setFont(new Font("굴림", Font.BOLD, 16));
		label4.setBounds(372, 10, 40, 30);
		contentPane.add(label4);
		label5 = new JLabel("수학");
		label5.setFont(new Font("굴림", Font.BOLD, 16));
		label5.setBounds(496, 10, 40, 30);
		contentPane.add(label5);
		JLabel label6 = new JLabel("사탐");
		label6.setFont(new Font("굴림", Font.BOLD, 16));
		label6.setBounds(620, 10, 40, 30);
		contentPane.add(label6);
		JLabel label7 = new JLabel("과탐");
		label7.setFont(new Font("굴림", Font.BOLD, 16));
		label7.setBounds(876, 10, 40, 30);
		contentPane.add(label7);
		stdNumbField = new JTextField();
		stdNumbField.addMouseListener(mouseClick);
		stdNumbField.setBounds(64, 10, 60, 30);
		stdNumbField.setSize(60, 30);
		contentPane.add(stdNumbField);
		stdNumbField.setColumns(10);
		nameField = new JTextField();
		nameField.addMouseListener(mouseClick);
		nameField.setColumns(10);
		nameField.setBounds(176, 12, 60, 30);
		contentPane.add(nameField);
		korField = new JTextField();
		korField.addMouseListener(mouseClick);
		korField.setColumns(10);
		korField.setBounds(300, 12, 60, 30);
		contentPane.add(korField);
		engField = new JTextField();
		engField.addMouseListener(mouseClick);
		engField.setColumns(10);
		engField.setBounds(424, 12, 60, 30);
		contentPane.add(engField);
		mathField = new JTextField();
		mathField.addMouseListener(mouseClick);
		mathField.setColumns(10);
		mathField.setBounds(548, 12, 60, 30);
		contentPane.add(mathField);
		socField = new JTextField();
		socField.addMouseListener(mouseClick);
		socField.setColumns(10);
		socField.setBounds(804, 12, 60, 30);
		contentPane.add(socField);
		sciField = new JTextField();
		sciField.addMouseListener(mouseClick);
		sciField.setColumns(10);
		sciField.setBounds(1060, 12, 60, 30);
		contentPane.add(sciField);
	}

	MouseListener mouseClick = new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e) {
			// System.out.println(e.getSource());
			((JTextField) e.getSource()).setText("");
		}
	};
	List<String> datass;

	int parseInt(String scoreTitle, JTextField e) {
		String scoreStr = e.getText().trim();
		System.out.println(scoreStr);
		if (scoreStr.isEmpty()) {
			showMessage(scoreTitle + "값을 입력하세요");
			e.requestFocus();

			// parseInt(scoreTitle,scoreStr);
		}
		int score = Integer.parseInt(scoreStr);
		if (score < 0 || score > 100) {
			showMessage(scoreTitle + "0~100사이의 숫자를 입력하세요");
			// parseInt(scoreTitle,scoreStr);
			e.requestFocus();

		}
		return score;
	}

	public void btnFunction() {
		JComboBox<String> selectSocBox = new JComboBox<String>();
		selectSocBox.setModel(
				new DefaultComboBoxModel(new String[] { "과목선택", "한국지리", "세계지리", "경제지리", "국사", "세계사", "한국근현대사" }));
		selectSocBox.setBounds(672, 11, 120, 30);
		contentPane.add(selectSocBox);
		JComboBox<String> selectSciBox = new JComboBox<String>();
		selectSciBox.setModel(new DefaultComboBoxModel(new String[] { "과목선택", "물리", "화학", "생물", "지구과학" }));
		selectSciBox.setBounds(928, 11, 120, 30);
		contentPane.add(selectSciBox);
		JButton registBtn = new JButton("등록"); 
		registBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String hak = stdNumbField.getText();
				String name = nameField.getText();

				datass = new ArrayList<>();
				int socIndex = selectSocBox.getSelectedIndex(); // 1 ~ 6
				int sciIndex = selectSciBox.getSelectedIndex(); // 1 ~ 4
				if (!socIndexCheck(socIndex) || !sciIndexCheck(sciIndex)) {
					showMessage("과목을 선택 해 주세요");
					return;
				}
				if (name.matches("^[가-힣]*$") != true) {
					showMessage("이름은 완성형 한글만 입력가능합니다");
					return;
				}
				if (hak.matches("^[0-9]*$") != true) {
					showMessage("학번은 반드시 숫자여야만 합니다.");
					return;
				}
				int kor = parseInt("국어", korField);
				int eng = parseInt("영어", engField);
				int math = parseInt("수학", mathField);
				int soc = parseInt("사탐", socField);
				int sci = parseInt("과탐", sciField);
				int id = parseInt("학번", stdNumbField);
				int total = 0;
				double average = 0;
				try {
					total = kor + eng + math + soc + sci;
					average = total / 5.0f;
					datass.add(hak);
					datass.add(name);
					datass.add(kor + "");
					datass.add(eng + "");
					datass.add(math + "");
					for (int i = 1; i <= 6; i++) {
						datass.add((i == socIndex) ? soc + "" : "0");
					}
					for (int i = 1; i <= 4; i++) {
						datass.add((i == sciIndex) ? sci + "" : "0");
					}
					datass.add(String.valueOf(total));
					datass.add(String.valueOf(average));
					model.addRow(datass.toArray());

				} catch (NumberFormatException er) {
					showMessage("값은 반드시 숫자여야 합니다.");
				}
				
				List<Integer> list;
				//// Here it starts input into database
				StudentRecordInfo student = new StudentRecordInfo();
				student.setStudentId(id);
				student.setKorean(kor);
				student.setEnglish(eng);
				student.setMath(math);
				if (socIndex == 1)
					student.setKoreaGeo(soc);
				else if (socIndex == 2)
					student.setWorldGeo(soc);
				else if (socIndex == 3)
					student.setEconomicGeo(soc);
				else if (socIndex == 4)
					student.setHistory(soc);
				else if (socIndex == 5)
					student.setWorldHistory(soc);
				else
					student.setModernHistory(soc);

				if (sciIndex == 1)
					student.setPhysics(sci);
				else if (sciIndex == 2)
					student.setChemistry(sci);
				else if (sciIndex == 3)
					student.setLivingScience(sci);
				else
					student.setGeoscience(sci);
				student.setTotalScore(total);
				student.setAvg(average);
				student.setRank(rank);
				student.setStudentId(Integer.parseInt(stdNumbField.getText()));
				JDBCConnector con = new JDBCConnector();
				con.insertStudentGrade(student);

				StudentRecordInfo studentInfo = new StudentRecordInfo();
				studentInfo.setName(nameField.getText());
				studentInfo.setStudentId(Integer.parseInt(stdNumbField.getText()));
				JDBCConnector con2 = new JDBCConnector();
				con2.insertStudentInfo(studentInfo);

				setRanking();
				stdNumbField.setText("");
				nameField.setText("");
				korField.setText("");
				engField.setText("");
				mathField.setText("");
				selectSocBox.setSelectedIndex(0);
				selectSciBox.setSelectedIndex(0);
				socField.setText("");
				sciField.setText("");
			}
			int rank;
			private void setRanking() {
				int count = model.getRowCount();
				Map<Integer, Integer> rankData = new HashMap<>();
				for (int i = 0; i < count; i++) {
					rankData.put(i, Integer.parseInt(model.getValueAt(i, 15).toString()));
				}
				Iterator<Integer> it = sortByValue(rankData).iterator();
				rank = 1;
				while (it.hasNext()) {
					int index = (int) it.next();
					model.setValueAt(rank++, index, 17);
				}
			}

			public List<Integer> sortByValue(final Map map) {
				List<Integer> list = new ArrayList();
				list.addAll(map.keySet());
				Collections.sort(list, (o1, o2) -> {
					Object v1 = map.get(o1);
					Object v2 = map.get(o2);
					return ((Comparable) v2).compareTo(v1);
				});
				return list;
			}

			private boolean socIndexCheck(int socIndex) {
				return socIndex > 0 && socIndex <= 6;
			}

			private boolean sciIndexCheck(int sciIndex) {
				return sciIndex > 0 && sciIndex <= 4;
			}
		});
		registBtn.setFont(new Font("굴림", Font.BOLD, 14));
		registBtn.setBounds(1070, 50, 120, 40);
		contentPane.add(registBtn);
		JButton deleteBtn = new JButton("초기화");
		deleteBtn.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {

				while (model.getRowCount() > 0) {
					model.removeRow(0);

				}
			}
		});
		deleteBtn.setFont(new Font("굴림", Font.BOLD, 14));
		deleteBtn.setBounds(1070, 100, 120, 40);
		contentPane.add(deleteBtn);
		JButton help = new JButton("도움말");
		help.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,
						"학번, 국어, 영어, 수학, 사탐 그리고 과탐은 숫자로 빈 공간에 입력, 이름은 문자를 입력후 등록버튼을 눌러주세요.\"\r\n"
								+ "                  + \"\n\" + \"초기화버튼은 모든 데이타를 초기화 시킵니다");
			}
		});
		help.setFont(new Font("굴림", Font.BOLD, 14));
		help.setBounds(1070, 150, 120, 40);
		contentPane.add(help);
		theHandler handler = new theHandler();
		avgList = new JButton("평균");
		avgList.addActionListener(handler);
		avgList.setFont(new Font("굴림", Font.BOLD, 14));
		avgList.setBounds(1070, 200, 120, 40);
		contentPane.add(avgList);
		JPanel gradePanel = new JPanel();
		table.add(gradePanel, "gradePanel");
	}

	private void showMessage(String msg) {// ?⑤벏?꽰 占쎈퓠占쎌쑎筌∽옙
		JOptionPane.showMessageDialog(this, msg, "한심하구나", JOptionPane.WARNING_MESSAGE);
	}

	public class theHandler implements ActionListener {
		// 평균을 눌렀을때 이벤트 발생
		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == avgList) {
				Frame2 avgResult = new Frame2();
				avgResult.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

			}

		}

	}

	class Frame2 extends JFrame {

		int temp = 0;
		int sumsave = 0;// 사탐 점수 계산할때 각 열마다 돌때 값을 기억해두는 변수임.

		JFrame frame2 = new JFrame();
		String[] columnNames = { "국어", "영어", "수학", "사탐", "과탐" };
		Object[][] data = { { temp, temp, temp, temp, temp } };

		public float getSubjectSum(int colNum) {
			// 국수영의 경우, 사탐의 경우 2가지
			int sum = 0;
			int avg = 0;
			int rowNum = TeamProject2.table.getRowCount();
			if (colNum >= 2 && colNum <= 4) {
				// 국수영 평균 구하기
				if (TeamProject2.table.getRowCount() > 0) {
					for (int i = 0; i < rowNum; i++) {
						temp = avg;
						sum += Integer.parseInt(TeamProject2.table.getValueAt(i, colNum).toString());
						avg = sum / rowNum;
					}
				}
			}
			// 사탐과탐 평균 구하기 : 6~10열 사탐 11~14 과탐
			else {
				if (TeamProject2.table.getRowCount() > 0) {

					for (int i = 0; i < TeamProject2.table.getRowCount(); i++) {
						temp = avg;
						sum += Integer.parseInt(TeamProject2.table.getValueAt(i, colNum).toString());

					}
					sumsave += sum;
					avg = sumsave / rowNum;
				}
			}

			return avg;
		}

		public Frame2() {
			super("평균성적");
			JTable table = new JTable(data, columnNames);

			// 차례대로 국수영 평균이다.
			table.setValueAt(getSubjectSum(2), 0, 0);
			table.setValueAt(getSubjectSum(3), 0, 1);
			table.setValueAt(getSubjectSum(4), 0, 2);
			// 사탐 평균이다.
			for (int i = 5; i <= 10; i++) {
				table.setValueAt(getSubjectSum(i), 0, 3);
			}
			// 과탐 평균이다.
			sumsave = 0; // 과탐점수 입력을 위해 변수를 초기화해 준다.
			for (int i = 11; i <= 14; i++) {
				table.setValueAt(getSubjectSum(i), 0, 4);
			}

			frame2.add(new JScrollPane(table));
			frame2.pack();
			frame2.setBounds(200, 200, 400, 100);
			frame2.setVisible(true);

		}
	}

}