package project;

public class StudentRecordInfo {
   private int studentId;
   private String name;
   private String email;
   private int phoneNum;
   private int korean;
   private int english;
   private int math;
   private int koreaGeo;
   private int worldGeo;
   private int economicGeo;
   private int history;
   private int worldHistory;
   private int modernHistory;
   private int physics;
   private int chemistry;
   private int livingScience;
   private int geoscience;
   private int totalScore;
   private double avg;
   private int rank;
   public StudentRecordInfo() {
      // TODO Auto-generated constructor stub
   }
   public int getStudentId() {
      return studentId;
   }

   public void setStudentId(int studentId) {
      this.studentId = studentId;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getEmail() {
      return email;
   }

   public void setEmail(String email) {
      this.email = email;
   }

   public int getPhoneNum() {
      return phoneNum;
   }

   public void setPhoneNum(int phoneNum) {
      this.phoneNum = phoneNum;
   }

   public int getKorean() {
      return korean;
   }

   public void setKorean(int korean) {
      this.korean = korean;
   }

   public int getEnglish() {
      return english;
   }

   public void setEnglish(int english) {
      this.english = english;
   }

   public int getMath() {
      return math;
   }

   public void setMath(int math) {
      this.math = math;
   }

   public int getKoreaGeo() {
      return koreaGeo;
   }

   public void setKoreaGeo(int koreaGeo) {
      this.koreaGeo = koreaGeo;
   }

   public int getWorldGeo() {
      return worldGeo;
   }

   public void setWorldGeo(int worldGeo) {
      this.worldGeo = worldGeo;
   }

   public int getEconomicGeo() {
      return economicGeo;
   }

   public void setEconomicGeo(int economicGeo) {
      this.economicGeo = economicGeo;
   }

   public int getHistory() {
      return history;
   }

   public void setHistory(int history) {
      this.history = history;
   }

   public int getWorldHistory() {
      return worldHistory;
   }

   public void setWorldHistory(int worldHistory) {
      this.worldHistory = worldHistory;
   }

   public int getModernHistory() {
      return modernHistory;
   }

   public void setModernHistory(int modernHistory) {
      this.modernHistory = modernHistory;
   }

   public int getPhysics() {
      return physics;
   }

   public void setPhysics(int physics) {
      this.physics = physics;
   }

   public int getChemistry() {
      return chemistry;
   }

   public void setChemistry(int chemistry) {
      this.chemistry = chemistry;
   }

   public int getLivingScience() {
      return livingScience;
   }

   public void setLivingScience(int livingScience) {
      this.livingScience = livingScience;
   }

   public int getGeoscience() {
      return geoscience;
   }

   public void setGeoscience(int geoscience) {
      this.geoscience = geoscience;
   }

   public int getTotalScore() {
      return totalScore;
   }

   public void setTotalScore(int totalScore) {
      this.totalScore = totalScore;
   }

   public double getAvg() {
      return avg;
   }

   public void setAvg(double avg2) {
      this.avg = avg2;
   }

   public int getRank() {
      return rank;
   }

   public void setRank(int rank) {
      this.rank = rank;
   }

   public StudentRecordInfo(int studentId, String name, int korean, int english, int math,
         int koreaGeo, int worldGeo, int economicGeo, int history, int worldHistory, int modernHistory, int physics,
         int chemistry, int livingScience, int geoscience, int totalScore, int avg, int rank) {
      super();
      this.studentId = studentId;
      this.name = name;
      this.korean = korean;
      this.english = english;
      this.math = math;
      this.koreaGeo = koreaGeo;
      this.worldGeo = worldGeo;
      this.economicGeo = economicGeo;
      this.history = history;
      this.worldHistory = worldHistory;
      this.modernHistory = modernHistory;
      this.physics = physics;
      this.chemistry = chemistry;
      this.livingScience = livingScience;
      this.geoscience = geoscience;
      this.totalScore = totalScore;
      this.avg = avg;
      this.rank = rank;
   }

   @Override
   public String toString() {
      return String.format(
            "StudentRecordInfo [studentId=%s, name=%s, email=%s, phoneNum=%s, korean=%s, english=%s, math=%s, koreaGeo=%s, worldGeo=%s, economicGeo=%s, history=%s, worldHistory=%s, modernHistory=%s, physics=%s, chemistry=%s, livingScience=%s, geoscience=%s, totalScore=%s, avg=%s, rank=%s]",
            studentId, name, email, phoneNum, korean, english, math, koreaGeo, worldGeo, economicGeo, history,
            worldHistory, modernHistory, physics, chemistry, livingScience, geoscience, totalScore, avg, rank);
   }

}