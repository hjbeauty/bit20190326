package project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JDBCConnector {
   private Connection conn;
   private PreparedStatement pStmt;
   private ResultSet result;

   
   
   //final의 차이점을 모르겠음.....그래서 그냥 만들어놈
   static public final JDBCConnector instance = new JDBCConnector();
   
   public JDBCConnector() {
      connection();
   }

   public void connection() {
      try {
         Class.forName("org.h2.Driver");
         conn = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
      } catch (ClassNotFoundException | SQLException e) {
         e.printStackTrace();
      }
   }

   // 조건에 맞는 데이터 리턴할 부분
   public StudentRecordInfo getStudentRecordInfo(String studentRecord) {
      StudentRecordInfo studentRecordInfo = null;
      
      String sql = "select * from studentrecord, studentgrade where studentrecord.studentid = studentgrade.studentid";
      
      try {
         pStmt = conn.prepareStatement(sql);
         pStmt.setInt(1, Integer.parseInt(studentRecord));
         result = pStmt.executeQuery();
         while(result.next()) {
            studentRecordInfo = new StudentRecordInfo(
                  result.getInt("studentid"), 
                  result.getString("name"),
                  result.getInt("korean"), 
                  result.getInt("english"),
                  result.getInt("math"),
                  result.getInt("koreaGeo"),
                  result.getInt("worldGeo"),
                  result.getInt("economicgeo"),
                  result.getInt("history"),
                  result.getInt("worldhistory"), 
                  result.getInt("modernhistory"),
                  result.getInt("physics"), 
                  result.getInt("chemistry"),
                  result.getInt("livingscience"),
                  result.getInt("geoscience"),
                  result.getInt("totalScore"),
                  result.getInt("avg"),
                  result.getInt("rank")
                  );
         }
      } catch (NumberFormatException e) {
         e.printStackTrace();
      } catch (SQLException e) {
         e.printStackTrace();
      }
      return studentRecordInfo;
   }
   
   //insert메소드인거 같은데 여기엔 rank, totalscore, avg가 필요없을듯.....
   public void insertStudentGrade(StudentRecordInfo studentGrade) {
      String sql = "insert into studentgrade (studentid, korean, english, math, koreageo, worldgeo, economicgeo, history, worldhistory,modernhistory, physics, chemistry, livingscience, geoscience, totalScore, avg, rank)  "
            + "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
      try {
         pStmt = conn.prepareStatement(sql);
         pStmt.setInt(1, studentGrade.getStudentId());
         pStmt.setInt(2, studentGrade.getKorean());
         pStmt.setInt(3, studentGrade.getEnglish());
         pStmt.setInt(4, studentGrade.getMath());
         pStmt.setInt(5, studentGrade.getKoreaGeo());
         pStmt.setInt(6, studentGrade.getWorldGeo());
         pStmt.setInt(7, studentGrade.getEconomicGeo());
         pStmt.setInt(8, studentGrade.getHistory());
         pStmt.setInt(9, studentGrade.getWorldHistory());
         pStmt.setInt(10, studentGrade.getModernHistory());
         pStmt.setInt(11, studentGrade.getPhysics());
         pStmt.setInt(12, studentGrade.getChemistry());
         pStmt.setInt(13, studentGrade.getLivingScience());
         pStmt.setInt(14, studentGrade.getGeoscience());
         pStmt.setInt(15, studentGrade.getTotalScore());
         pStmt.setDouble(16, studentGrade.getAvg());
         pStmt.setInt(17, studentGrade.getRank());
         
         
         int updateCount= pStmt.executeUpdate();
         System.out.println(updateCount);
      }catch (SQLException e) {
      }
   }
   
   public void insertStudentInfo(StudentRecordInfo studentInfo) {
	   String sql = "insert into studentrecord (studentid, name, email, phonenum) values (?,?,?,?)";
	   int id= 0;
	   String name=null;
	   String email = null;
	   int phoneNum = 0;
	   try {
		pStmt = conn.prepareStatement(sql);
		pStmt.setInt(1, studentInfo.getStudentId());
		pStmt.setString(2, studentInfo.getName());
		pStmt.setString(3, studentInfo.getEmail());
		pStmt.setInt(4, studentInfo.getPhoneNum());
		
		int updateCount = pStmt.executeUpdate();
		System.out.println(updateCount);
	} catch (SQLException e) {
		e.printStackTrace();
	}
	   
   }
}