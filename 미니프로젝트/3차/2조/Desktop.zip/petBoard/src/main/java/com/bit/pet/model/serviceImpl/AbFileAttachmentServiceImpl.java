package com.bit.pet.model.serviceImpl;

import com.bit.pet.model.service.AbFileAttachmentService;

public class AbFileAttachmentServiceImpl implements AbFileAttachmentService {

}
