package com.bit.pet.model.dao;

public interface JbFileAttachmentMapper {

}
