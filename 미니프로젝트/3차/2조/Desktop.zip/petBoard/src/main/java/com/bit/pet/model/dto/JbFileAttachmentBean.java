package com.bit.pet.model.dto;

public class JbFileAttachmentBean {
	private int imageNum;
	private int jbNum;
	private String fileName;
	
	
	
	
}
