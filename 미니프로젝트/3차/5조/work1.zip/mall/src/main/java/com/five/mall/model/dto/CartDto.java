package com.five.mall.model.dto;

public class CartDto {

	private int cartNo;
	private String userId;
	private String name;
	private int productNo;
	private String productName;
	private int amount;
	private int productPrice;
	private int money;
	
	public int getCartNo() {
		return cartNo;
	}
	public void setCartNo(int cartNo) {
		this.cartNo = cartNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getProductNo() {
		return productNo;
	}
	public void setProductNo(int productNo) {
		this.productNo = productNo;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	@Override
	public String toString() {
		return "CartDto [cartNo=" + cartNo + ", userId=" + userId + ", name=" + name + ", productNo=" + productNo
				+ ", productName=" + productName + ", productPrice=" + productPrice + ", money=" + money + ", amount="
				+ amount + "]";
	}
}
