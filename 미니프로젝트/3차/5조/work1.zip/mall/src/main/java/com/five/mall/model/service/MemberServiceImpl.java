package com.five.mall.model.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.five.mall.model.dao.MemberDaoMapper;
import com.five.mall.model.dto.MemberDto;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberDaoMapper dao;

	@Override
	public boolean loginCheck(MemberDto dto, HttpSession session) {

		String name = dao.loginCheck(dto);

		if (name != null) {
			session.setAttribute("userId", dto.getUserId());
			session.setAttribute("name", name);
			return true;
		}else {
			return false;
		}
	}

	@Override
	public List<MemberDto> getMemberList() {
		List<MemberDto> list = dao.getMemberList();
		return list;
		
	}
}
