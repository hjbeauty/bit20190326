package com.five.mall.model.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.five.mall.model.dto.MemberDto;

public interface MemberService {

	public boolean loginCheck(MemberDto dto, HttpSession session);

	public List<MemberDto> getMemberList();
}
