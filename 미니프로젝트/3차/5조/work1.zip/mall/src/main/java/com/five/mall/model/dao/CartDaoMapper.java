package com.five.mall.model.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.five.mall.model.dto.CartDto;

@Mapper
public interface CartDaoMapper {

	@Select("select productName, nvl(sum(productPrice*amount),0) money from cart c, product p" + 
			" where c.productNo=p.productNo group by productName order by productName")
	public List<CartDto> cartMoney();
	
	@Insert("insert into cart (cartNo,userId,productNo,amount) values (cartSeq.nextval,#{userId},#{productNo},#{amount})")
	public void insert(CartDto dto);
	
	@Select("select cartNo, m.userId, name, p.productNo, productName, amount, productPrice, nvl(productPrice*amount,0) money" + 
			" from member m, cart c, product p" + 
			" where m.userId=c.userId and p.productNo=c.productNo and m.userId=#{userId}")
	public List<CartDto> listCart(String userId);
	
	@Delete("delete from cart where cartNo=#{cartNo}")
	public void delete(int cartNo);
	
	@Delete("delete from cart where userId=#{userId}")
	public void deleteAll(String userId);
	
	public void update(int cartNo);
	
	@Select("select nvl(sum(productPrice*amount),0) money from product p, cart c" + 
			" where p.productNo=c.productNo and userId=#{userId}")
	public int sumMoney(String userId);
	
	public int countCart(String userId, int productNo);
	
	public void updateCart(CartDto dto);
	
	@Update("update cart set amount=#{amount} where cartNo=#{cartNo}")
	public void modifyCart(CartDto dto);
}
