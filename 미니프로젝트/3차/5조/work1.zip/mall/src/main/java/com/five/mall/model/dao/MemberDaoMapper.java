package com.five.mall.model.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.five.mall.model.dto.MemberDto;

@Mapper
public interface MemberDaoMapper {

	@Select("select name from member where userId=#{userId} and password=#{password}")
	public String loginCheck(MemberDto dto);
	
	public MemberDto viewMember(String userId);

	@Select("select * from member")
	public List<MemberDto> getMemberList();
}
