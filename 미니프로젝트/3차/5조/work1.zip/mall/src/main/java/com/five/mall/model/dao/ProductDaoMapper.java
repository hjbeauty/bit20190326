package com.five.mall.model.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.five.mall.model.dto.ProductDto;

@Mapper
public interface ProductDaoMapper {

	@Select("select * from product order by productName")
	public List<ProductDto> listProduct();
	
	@Select("select * from product where productNo=#{productNo}")
	public ProductDto detailProduct(int productNo);
	
	@Update("update product set productName=#{productName},productPrice=#{productPrice},productDesc=#{productDesc},pictureUrl=#{pictureUrl} where productNo=#{productNo}")
	public void updateProduct(ProductDto dto);
	
	@Delete("delete from product where productNo=#{productNo}")
	public void deleteProduct(int productNO);
	
	@Insert("insert into product values (productseq.nextval,#{productName},#{productPrice},#{productDesc},#{pictureUrl})")
	public void insertProduct(ProductDto dto);
	
	@Select("select pictureUrl from product where productNo=#{productNo}")
	public String attachedFileInfo(int productNo);

}
