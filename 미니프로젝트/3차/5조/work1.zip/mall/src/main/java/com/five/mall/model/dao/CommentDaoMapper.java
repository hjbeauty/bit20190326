package com.five.mall.model.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.five.mall.model.dto.CommentDto;

@Mapper
public interface CommentDaoMapper {

	@Insert("insert into commentz(commentNo,productNo,userId,commentContent) values (commentSeq.nextval,#{productNo},#{userId},#{commentContent})")
	public void insertComment(CommentDto dto);
	
	@Select("select * from commentz where productNo=#{productNo}")
	public List<CommentDto> listComment(int productNo);
	
	@Delete("delete from commentz where commentNo=#{commentNo}")
	public void deleteComment(int commentNo);
}
