package com.five.mall.controller;

import java.io.File;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.five.mall.model.dto.CommentDto;
import com.five.mall.model.dto.ProductDto;
import com.five.mall.model.service.CommentService;
import com.five.mall.model.service.ProductService;

@Controller
public class ProductController {

	@Autowired
	private ProductService productService;
	@Autowired
	private CommentService commentService;
	
	@RequestMapping("/")
	public String home() {
		return "home";
	}

	@RequestMapping("/productList.do")
	public String list(Model model) {
		List<ProductDto> list = productService.listProduct();
		model.addAttribute("list", list);
		return "product/productList";
	}

	@RequestMapping("/productDetail.do")
	public String detail(int productNo, Model model) {
		ProductDto dto = productService.detailProduct(productNo);
		model.addAttribute("dto", dto);
		List<CommentDto> cList = commentService.listComment(productNo);
		model.addAttribute("cList", cList);
		return "product/productDetail";
	}

	@RequestMapping("/productWrite.do")
	public String write() {
		return "product/productWrite";
	}

	@RequestMapping("/productInsert.do")
	public String insert(ProductDto dto) {
		String fileName = "Empty";
		if (!dto.getFile().isEmpty()) {
			UUID uuid = UUID.randomUUID();
			String uid = uuid.toString();
			fileName = uid + "_" + dto.getFile().getOriginalFilename();
			try {
				String path = "D:\\stsboot-workspace\\mall\\src\\main\\resources\\static\\images\\";
				// String path="C:\\workspace-sts-3.9.7\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\FiveJo\\src\\main\\webapp\\resources\\images\\";
				// String path="C:\\sts-bundle\\pivotal-tc-server\\instances\\base-instance\\wtpwebapps\\FiveJo\\resources\\images\\";
				// new File(path).mkdir();
				dto.getFile().transferTo(new File(path + fileName));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		dto.setPictureUrl(fileName);
		productService.insertProduct(dto);
		return "redirect:productList.do";
	}

	@RequestMapping("/productEdit.do")
	public String edit(int productNo, Model model) {
		ProductDto dto = productService.detailProduct(productNo);
		model.addAttribute("dto", dto);
		return "product/productEdit";
	}

	@RequestMapping("/productUpdate.do")
	public String update(ProductDto dto) {
		if (!dto.getFile().isEmpty()) {
			String fileName = dto.getFile().getOriginalFilename();
			try {
				String path = "D:\\stsboot-workspace\\mall\\src\\main\\resources\\static\\images\\";
				dto.getFile().transferTo(new File(path + fileName));
			} catch (Exception e) {
				e.printStackTrace();
			}
			dto.setPictureUrl(fileName);
		} 
		productService.updateProduct(dto);
		return "redirect:productList.do";
	}
	
	@RequestMapping("/productDelete.do")
	public String delete(ProductDto dto) {
		String fileName=dto.getPictureUrl();
		if(!fileName.equals("Empty")) {
			String path = "D:\\stsboot-workspace\\mall\\src\\main\\resources\\static\\images\\";
			File f=new File(path+fileName);
			if(f.exists()) {
				f.delete();
			}
		}
		productService.deleteProduct(dto.getProductNo());
		return "redirect:productList.do";
	}
	
}
