package com.five.mall.model.dto;

import java.util.Date;

public class MemberDto {

	private String userId;
	private String password;
	private String name;
	private String address;
	private String phone;
	private String email;
	private String birth;
	private Date joinDate;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public Date getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}
	@Override
	public String toString() {
		return "MemberDto [userId=" + userId + ", password=" + password + ", name=" + name + ", address=" + address
				+ ", phone=" + phone + ", email=" + email + ", birth=" + birth + ", joinDate=" + joinDate + "]";
	}
	
	
	
	
	
}
