package com.five.mall.model.service;

import com.five.mall.model.dto.EmailDto;

public interface EmailService {

	public void sendMail(EmailDto dto);
}
