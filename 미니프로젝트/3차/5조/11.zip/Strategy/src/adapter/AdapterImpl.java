package adapter;

public class AdapterImpl implements Adapter{

	@Override
	public Float twiceOf(Float f) {
		return (float)Math.twoTime(f.doubleValue());

		//자동변환되는거 같은데 (좀 억지같으나) 알맞게 변화되는 로직이 필요.
	}

	@Override
	public Float halfOf(Float f) {
		return (float)Math.half(f.doubleValue());
	}
	
}
