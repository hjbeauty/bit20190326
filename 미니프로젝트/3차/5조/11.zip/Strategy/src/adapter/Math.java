package adapter;

public class Math {

	//두배

	public static double twoTime(double num){

	return num*2;

	}

	//절반

	public static double half(double num){

	return num/2;

	}

	//위의 두 함수는 double, 요구사항은 float 이므로 약간 맞지 않는다.
}
