package strategy;

public class Main {

	public static void main(String[] args) {
		User user = new User();

		user.attack();

		user.setWeapon(new Knife());

		user.attack();

		user.setWeapon(new Sword());

		user.attack();
		user.setWeapon(new Ax());

		user.attack();
	}
}
