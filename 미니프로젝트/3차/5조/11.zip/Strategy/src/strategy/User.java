package strategy;

public class User {

	//접근점

	private Weapon weapon;



	//교환가능

	public void setWeapon(Weapon weapon){

	this.weapon = weapon;

	}



	public void attack(){

	//공격방법 위임

	if(weapon==null){

	System.out.println("맨손 공격");

	}else{

	weapon.attack();

	}

	}
}
