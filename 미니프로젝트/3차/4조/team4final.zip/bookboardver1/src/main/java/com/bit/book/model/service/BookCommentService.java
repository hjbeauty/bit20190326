package com.bit.book.model.service;

import java.util.List;

import com.bit.book.model.dto.BookCommentBean;

public interface BookCommentService {
public List<BookCommentBean> showCommList(int boardNo) throws Exception;
	
	public void createComm(BookCommentBean bookCommentBean) throws Exception;
	
	public void deleteComm(int commentNo) throws Exception;
	
	//별점 
		public List<Integer> getCommentRating (int boardNo) throws Exception;
	

}
