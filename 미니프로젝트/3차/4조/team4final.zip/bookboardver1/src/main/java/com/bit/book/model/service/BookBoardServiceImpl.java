package com.bit.book.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bit.book.model.dao.BookBoardMapper;
import com.bit.book.model.dto.BookBoardBean;
import com.bit.book.model.dto.BookCommentBean;

@Service("BookBoardService")
public class BookBoardServiceImpl implements BookBoardService {
	
	@Autowired
	BookBoardMapper bookBoardMapper;

	@Override
	public BookBoardBean read(int boardNo) throws Exception {
	BookBoardBean selectedBean = bookBoardMapper.read(boardNo);
		return selectedBean;
	}
	@Override
	public void BookUpdate()  {
		bookBoardMapper.BookUpdate();
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void upviews(int boardNo) {
		bookBoardMapper.upviews(boardNo);
		
	}
	@Override
	public List<BookBoardBean> getAllgenre() {
		
		List<BookBoardBean> beans = bookBoardMapper.getAllGenre();
		return beans;
	}

	@Override
	public List<BookBoardBean> getAllList() {
		List<BookBoardBean> bean = bookBoardMapper.getAllList();
		return bean;
	}

	@Override
	public List<BookBoardBean> getNobleGenre() {
		List<BookBoardBean> bean = bookBoardMapper.getNobleGenre();
		return bean;
	}

	@Override
	public List<BookBoardBean> getDevelopGenre() {
		List<BookBoardBean> bean = bookBoardMapper.getDevelopGenre();
		return bean;
	}

	@Override
	public List<BookBoardBean> getForeignLanguageGenre() {
		List<BookBoardBean> bean = bookBoardMapper.getForeignLanguageGenre();
		return bean;
	}

	@Override
	public List<BookBoardBean> getItGenre() {
		List<BookBoardBean> bean = bookBoardMapper.getItGenre();
		return bean;
	}
	@Override
	public List<BookBoardBean> getSearchList(String keyword) {
		List<BookBoardBean> bean = bookBoardMapper.getSearchList(keyword);
		return bean;
	}
	

}