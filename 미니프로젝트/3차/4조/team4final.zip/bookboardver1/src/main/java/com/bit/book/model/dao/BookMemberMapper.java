package com.bit.book.model.dao;

import com.bit.book.model.dto.BookMemberBean;

public interface BookMemberMapper {
	BookMemberBean getMemberInfo(BookMemberBean bean);
	int joinMember(BookMemberBean bean);	
	BookMemberBean joinIdCheck(String id);
	
}