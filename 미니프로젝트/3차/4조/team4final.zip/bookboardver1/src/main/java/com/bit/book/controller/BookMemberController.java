package com.bit.book.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bit.book.model.dto.BookMemberBean;
import com.bit.book.model.service.BookMemberService;



@Controller
public class BookMemberController {
	
	private static final Logger logger = LoggerFactory.getLogger(BookMemberController.class);
	
	@Autowired
	BookMemberService bookMemberService;	
	
	@RequestMapping("/login")
	public String login() {
	 return "member/login";	
	}

	@RequestMapping(value="/loginProcess", method=RequestMethod.POST)
	public String loginProcess(BookMemberBean bean, HttpSession session) {

		session.setAttribute("id", bean.getId());
		session.setAttribute("user", bean);
		String nextPage = bookMemberService.isBookMember(bean)? "redirect:/" : "redirect:login"; 

		return nextPage;
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session, HttpServletRequest req) throws Exception{
		session.invalidate();
		String prePage = req.getRequestURI();
		System.out.println(prePage);
		
		return "redirect:/";
	}	

	@RequestMapping("/join")
	public String join() {
		return "member/join";
	}	
	
	@RequestMapping("/joinIdCheck")
	public void joinIdCheck(HttpServletResponse res, @RequestParam("id") String id) throws IOException {
		bookMemberService.joinIdCheck(id, res);
	}
	
	@RequestMapping(value="/joinProcess", method = RequestMethod.POST)
	public String joinProcess(BookMemberBean bean) {
		bookMemberService.joinMember(bean);
		return "redirect:/";
	}
	
}
