package com.bit.book;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.bit.book.model.dto.BookBoardBean;
import com.bit.book.model.service.BookBoardService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class StartController {
	
	@Autowired
	BookBoardService bookBoardService;
	private static final Logger logger = LoggerFactory.getLogger(StartController.class);

	@RequestMapping("/")
	public String index(Model model,HttpSession session,BookBoardBean bean) {

		List<BookBoardBean> bookBoardAll = bookBoardService.getAllList();
		model.addAttribute("bookBoardAll", bookBoardAll);

		return "index";
	}
	
	@RequestMapping("/home")
	public String home(Model model) {		
		List<BookBoardBean> bookBoardAll = bookBoardService.getAllList();
		model.addAttribute("bookBoardAll", bookBoardAll);
		
		return "index";
	}
	
	
	
}
