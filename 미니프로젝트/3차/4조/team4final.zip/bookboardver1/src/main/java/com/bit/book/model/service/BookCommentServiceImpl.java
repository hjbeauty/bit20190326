package com.bit.book.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bit.book.model.dao.BookBoardMapper;
import com.bit.book.model.dao.BookCommentMapper;
import com.bit.book.model.dto.BookCommentBean;

@Service
public class BookCommentServiceImpl implements BookCommentService {
	@Autowired
	private BookCommentMapper bookCommentMapper;
	
	@Autowired
	BookBoardMapper bookBoardMapper;
	
	
	@Override
	public List<BookCommentBean> showCommList(int boardNo) throws Exception {
		// TODO Auto-generated method stub
		List<BookCommentBean> bean = bookCommentMapper.showCommList(boardNo);
		return bean;
	}

	@Override
	public void createComm(BookCommentBean bookCommentBean) throws Exception {
		// TODO Auto-generated method stub
		
		bookCommentMapper.createComm(bookCommentBean);
		bookBoardMapper.BookUpdate();
		
	}

	@Override
	public void deleteComm(int commentNo) throws Exception {
		// TODO Auto-generated method stub
		
		bookCommentMapper.deleteComm(commentNo);
		bookBoardMapper.BookUpdate();
	}
	
	@Override
	public List<Integer> getCommentRating(int boardNo) throws Exception {
		List<Integer> commentRatingList = bookCommentMapper.getCommentRating(boardNo);
		return commentRatingList;
	}

}
