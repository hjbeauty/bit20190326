package com.bit.book.model.service;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bit.book.model.dao.BookMemberMapper;
import com.bit.book.model.dto.BookMemberBean;

@Service("bookMemberService")
public class BookMemberServiceImpl implements BookMemberService {

	@Autowired
	BookMemberMapper bookMemberMapper;
	
	@Override	
	public boolean isBookMember(BookMemberBean bean) {
		// TODO Auto-generated method stub
		return bookMemberMapper.getMemberInfo(bean) != null;
	}

	@Override
	public int joinMember(BookMemberBean bean) {
		// TODO Auto-generated method stub
		return bookMemberMapper.joinMember(bean);
	}

	@Override
	public void joinIdCheck(String id, HttpServletResponse res) throws IOException {
		BookMemberBean bean = new BookMemberBean();
		bean = bookMemberMapper.joinIdCheck(id);
		
		if(bean == null) {
			res.getWriter().print("1");
		} else {
			res.getWriter().print("0");
		}
		
	}

}
