package com.bit.book.model.dto;

import java.sql.Date;

import org.springframework.web.multipart.MultipartFile;

public class BookBoardBean {
	 private int boardNo;
     private String id;
     private String bookName;
     private String bookWriter;
     private String publisher;
     private String genre;
     private String contents;
     private int price;
     private int likes;
     private int dislikes;
     private int views;
     private Date bookBoardTime;
     private String imageUrl;     
     private MultipartFile attachedFile;
     private int totalRating;
     private int commCnt;
     
	
	public MultipartFile getAttachedFile() {
		return attachedFile;
	}
	public void setAttachedFile(MultipartFile attachedFile) {
		this.attachedFile = attachedFile;
	}
	public int getCommCnt() {
		return commCnt;
	}
	public void setCommCnt(int commCnt) {
		this.commCnt = commCnt;
	}
	public int getBoardNo() {
		return boardNo;
	}
	public void setBoardNo(int boardNo) {
		this.boardNo = boardNo;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getBookWriter() {
		return bookWriter;
	}
	public void setBookWriter(String bookWriter) {
		this.bookWriter = bookWriter;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getLikes() {
		return likes;
	}
	public void setLikes(int likes) {
		this.likes = likes;
	}
	public int getDislikes() {
		return dislikes;
	}
	public void setDislikes(int dislikes) {
		this.dislikes = dislikes;
	}
	public int getViews() {
		return views;
	}
	public void setViews(int views) {
		this.views = views;
	}
	public Date getBookBoardTime() {
		return bookBoardTime;
	}
	public void setBookBoardTime(Date bookBoardTime) {
		this.bookBoardTime = bookBoardTime;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public int getTotalRating() {
		return totalRating;
	}
	public void setTotalRating(int totalRating) {
		this.totalRating = totalRating;
	}    
	     
	
	
}

