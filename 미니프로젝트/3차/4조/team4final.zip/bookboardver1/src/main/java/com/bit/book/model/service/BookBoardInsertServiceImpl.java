package com.bit.book.model.service;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bit.book.model.dao.BookBoardInsertMapper;
import com.bit.book.model.dto.BookBoardBean;

@Service
public class BookBoardInsertServiceImpl implements BookBoardInsertService {
	
	@Autowired
	private BookBoardInsertMapper bookBoard;
	
	@Override
	public void insert(BookBoardBean bookboard) {
		
		 bookBoard.insert(bookboard);
	}

	@Override
	public String attachedFileInfo(int boardNo) {
		// TODO Auto-generated method stub
		return bookBoard.attachedFileInfo(boardNo);
	}

	@Override
	public void updateBook(BookBoardBean bookboard) {
		bookBoard.updateBook(bookboard);
	}

	@Override
	public void bookDelet(int boardNo) {
		bookBoard.bookDelet(boardNo);
	}

	@Override
	public BookBoardBean editBook(int boardNo) {
		return bookBoard.editBook(boardNo);
		
	}



}
