package com.bit.book.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.bit.book.model.dto.BookBoardBean;
import com.bit.book.model.dto.BookCommentBean;
import com.bit.book.model.service.BookBoardService;
import com.bit.book.model.service.BookCommentService;

@Controller
public class BookBoardController {
	private static final Logger logger = LoggerFactory.getLogger(BookBoardController.class);
	@Autowired
	BookBoardService bookBoardService;
	
	@Autowired
	private BookCommentService bookCommentService;
	
	
	@RequestMapping(value="/read", method= RequestMethod.GET)
	public String read(@RequestParam("no") int boardNo, Model model) {
		//게시글 상세 출력
		try {
			bookBoardService.upviews(boardNo);
			BookBoardBean selectedBoard = bookBoardService.read(boardNo);
			model.addAttribute("selectedBoard",bookBoardService.read(boardNo));
			
			System.out.println("selectedBoard"+selectedBoard);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		//리뷰 목록 출력
		System.out.println(boardNo);
		try {
			
			List<BookCommentBean> bookCommentSelected = bookCommentService.showCommList(boardNo);
			model.addAttribute("bookCommentSelected", bookCommentSelected);
			System.out.println("bookCommentSelected"+bookCommentSelected);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//별점 리스트 가져오기
		//별점 리스트 불러오기
		try {
			List<Integer> commentRatingList = bookCommentService.getCommentRating(boardNo);
			model.addAttribute("commentRatingList", commentRatingList);
			System.out.println("commentRatingList"+ commentRatingList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	 return "board/bookpage";	
	}
	
	//리뷰 등록
	@RequestMapping(value="/commentWriteProcess", method= {RequestMethod.GET,RequestMethod.POST})
	public String commentWriteProcess2(@RequestParam("boardNo") int boardNo, BookCommentBean bookCommentBean, Model model) {
		
		SimpleDateFormat format1 = new SimpleDateFormat("MM-dd HH:mm:ss");
		Date curTime = new Date();
		String curTimeFmt = format1.format(curTime);
		
		bookCommentBean.setCommentTime(curTime);
		bookCommentBean.setBoardNo(boardNo);
		
		System.out.println("확인2"+bookCommentBean);
		
		try {
			bookCommentService.createComm(bookCommentBean);
			System.out.println("등록 & 댓글 카운트 갱신 성공!");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	

		return "redirect:/read?no="+boardNo;
		//return "redirect:commentUpdateProcess";
	}
	
	//리뷰 삭제
	@RequestMapping(value="/commentDeleteProcess", method= {RequestMethod.GET,RequestMethod.POST})
	public String commentDeleteProcess(@RequestParam("commentNo") int commentNo, BookCommentBean bookCommentBean, Model model, HttpServletRequest request) {
		String referer = request.getHeader("Referer");
		try {
			bookCommentService.deleteComm(commentNo);
			System.out.println("삭제 & 댓글 카운트 갱신성공!");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "redirect:"+referer;
		
	}
	@RequestMapping("/genreAll")
	public String allList(Model model) {
		List<BookBoardBean> allGenreList = bookBoardService.getAllgenre();
		model.addAttribute("genreAll", allGenreList);
		System.out.println(allGenreList);
		return "board/genreAllPage";
	}

	@RequestMapping("/genreDev")
	public String genreDevelop(Model model) {
		List<BookBoardBean> devGenreList = bookBoardService.getDevelopGenre();
		model.addAttribute("genreDev", devGenreList);
		return "board/genreDevPage";
	}
	
	@RequestMapping("/genreForeign")
	public String genreForeign(Model model) {
		List<BookBoardBean> foreignGenreList = bookBoardService.getForeignLanguageGenre();
		model.addAttribute("genreForeign", foreignGenreList);
		return "board/genreForeignPage";
	}
	
	@RequestMapping("/genreNoble")
	public String genreNoble(Model model) {
		List<BookBoardBean> nobleGenreList = bookBoardService.getNobleGenre();
		model.addAttribute("genreNoble", nobleGenreList);
		return "board/genreNoblePage";
	}
	
	@RequestMapping("/genreIt")
	public String genreIt(Model model) {
		List<BookBoardBean> itGenreList = bookBoardService.getItGenre();
		model.addAttribute("genreIt", itGenreList);
		return "board/genreItPage";
	}
	
	@RequestMapping("/searchList")
	public String searchList(@RequestParam("keyword") String keyword, Model model) {
		List<BookBoardBean> searchList = bookBoardService.getSearchList(keyword);
		model.addAttribute("searchList", searchList);
		System.out.println(bookBoardService.getSearchList(keyword));
		return "board/searchList";
	}	


}
