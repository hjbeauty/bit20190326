package com.bit.book.model.dao;

import java.util.List;

import com.bit.book.model.dto.BookBoardBean;
import com.bit.book.model.dto.BookCommentBean;


public interface BookBoardMapper {

	public BookBoardBean read(int boardNo)throws Exception;
	List<BookBoardBean> getAllList();
	List<BookBoardBean> getAllGenre();
	List<BookBoardBean> getNobleGenre();
	List<BookBoardBean> getDevelopGenre();
	List<BookBoardBean> getForeignLanguageGenre();
	List<BookBoardBean> getItGenre();
	List<BookBoardBean> getSearchList(String keyword);
	
	public void upviews(int boardNo);
	
	//별점처리 2
	public void BookUpdate();
}