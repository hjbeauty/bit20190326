package com.bit.book.model.service;

import com.bit.book.model.dto.BookBoardBean;

	
public interface BookBoardInsertService {
	
	public BookBoardBean editBook(int boardNo);
	
	public void insert(BookBoardBean bookboard);
	
	public String attachedFileInfo(int boardNo);
	
	public void updateBook(BookBoardBean bookboard);
	
	public void bookDelet(int boardNo);
	
}
