package com.bit.book.model.dto;

import java.util.Date;

public class BookCommentBean {
	private int commentNo;
	private int boardNo;
	private String content;
	private String id;
	private Date commentTime;
	private int commentRating;
	public int getCommentRating() {
		return commentRating;
	}
	public void setCommentRating(int commentRating) {
		this.commentRating = commentRating;
	}
	public int getCommentNo() {
		return commentNo;
	}
	public void setCommentNo(int commentNo) {
		this.commentNo = commentNo;
	}
	public int getBoardNo() {
		return boardNo;
	}
	public void setBoardNo(int boardNo) {
		this.boardNo = boardNo;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Date getCommentTime() {
		return commentTime;
	}
	public void setCommentTime(Date commentTime) {
		this.commentTime = commentTime;
	}
	@Override
	public String toString() {
		return "BookCommentBean [commentNo=" + commentNo + ", boardNo=" + boardNo + ", content=" + content + ", id="
				+ id + ", commentTime=" + commentTime + ", commentRating=" + commentRating + "]";
	}
	
	
	
}
