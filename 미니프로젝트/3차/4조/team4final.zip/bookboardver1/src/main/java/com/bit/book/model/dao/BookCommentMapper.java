package com.bit.book.model.dao;
import java.util.List;

import com.bit.book.model.dto.BookCommentBean;

public interface BookCommentMapper {
	
	public List<BookCommentBean> showCommList(int boardNo) throws Exception;
	
	public void createComm(BookCommentBean bookCommentBean) throws Exception;
	
	public void deleteComm(int commentNo) throws Exception;
	
	//별점처리메소드
		public List<Integer> getCommentRating (int boardNo) throws Exception;
	
}

