package com.bit.book.controller;
 
import java.io.File;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bit.book.model.dto.BookBoardBean;
import com.bit.book.model.service.BookBoardInsertService;
 
@Controller
public class BookBoardInsertController {
   
   @Autowired
   BookBoardInsertService bookService;
   
   
   @RequestMapping("/book")
   public String book() {
      return "member/login";
   }
   
   @RequestMapping("/bookboard")
   public String board() {
      return "redirect:/";
   }
   
   @RequestMapping("/writeView")
      public String write() {
         return "write/insertBoard";
      }
   
      //占쏙옙품 占쏙옙占� 처占쏙옙 占쏙옙占쏙옙
     @RequestMapping(value="/write.do", method=RequestMethod.POST)
     public String insert(BookBoardBean bookboard,HttpSession session) {
        System.out.println("들어옴");
        String fileName = "noAttachment";
        
         if (!bookboard.getAttachedFile().isEmpty()) {
            fileName = bookboard.getAttachedFile().getOriginalFilename();
            try {
               String path = "C:\\Users\\BeomHong\\spring3-workspace\\bookboardver1\\src\\main\\webapp\\resources\\images";
               
               bookboard.getAttachedFile().transferTo(new File(path + fileName));
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
         bookboard.setImageUrl(fileName);
         String id = (String) session.getAttribute("id");
         bookboard.setId(id);
         bookService.insert(bookboard);
         return "redirect:/";
      }
     
     @RequestMapping("/editBook.do")
     public String edit(int boardNo,Model model) {
        BookBoardBean bookBoard = bookService.editBook(boardNo);
        model.addAttribute("bookBoard",bookBoard);
        return "write/editBook";
     }     
     
     @RequestMapping("/bookUpdate.do")
      public String update(BookBoardBean bookboard) {
         if (!bookboard.getAttachedFile().isEmpty()) {
            String fileName = bookboard.getAttachedFile().getOriginalFilename();
            try {
               String path = "C:\\Users\\BeomHong\\spring3-workspace\\bookboardver1\\src\\main\\webapp\\resources\\images";
               bookboard.getAttachedFile().transferTo(new File(path + fileName));
            } catch (Exception e) {
               e.printStackTrace();
            }
            bookboard.setImageUrl(fileName);
         } 
         bookService.updateBook(bookboard);
         return "redirect:/";
      }

      @RequestMapping(value="/bookDelete.do", method=RequestMethod.POST)
      public String delete(BookBoardBean bookboard,HttpSession session) {
         System.err.println(1);
         int fileNo = bookboard.getBoardNo();
         String fileName = bookboard.getImageUrl();
         String bookName=bookboard.getBookName();
         String bookWriter=bookboard.getBookWriter();
         String genre=bookboard.getGenre();
         System.out.println(fileNo);
         System.out.println(bookName);
         System.out.println(bookWriter);
         System.out.println(genre);
         System.err.println(2);
         System.out.println(fileNo);
         System.out.println(fileName);
         if(!fileName.equals("noAttachment")) {  
            System.err.println(3);
            String path = "C:\\Users\\BeomHong\\spring3-workspace\\bookboardver1\\src\\main\\webapp\\resources\\images";
            System.err.println(4);
            File f=new File(path+fileName);
            System.err.println(5);
            if(f.exists()) {
               System.err.println(6);
               f.delete();
               System.err.println(7);
            }
         }
         bookService.bookDelet(bookboard.getBoardNo());
         return "redirect:/";
      }

   }
