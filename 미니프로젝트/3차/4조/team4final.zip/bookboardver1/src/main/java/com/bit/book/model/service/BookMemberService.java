package com.bit.book.model.service;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import com.bit.book.model.dto.BookMemberBean;

public interface BookMemberService {
	boolean isBookMember(BookMemberBean bean);
	int joinMember(BookMemberBean bean);
	void joinIdCheck(String id, HttpServletResponse res) throws IOException;
}
