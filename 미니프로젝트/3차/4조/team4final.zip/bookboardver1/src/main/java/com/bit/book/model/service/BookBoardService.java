package com.bit.book.model.service;

import java.util.List;

import com.bit.book.model.dto.BookBoardBean;
import com.bit.book.model.dto.BookCommentBean;


public interface BookBoardService {
	
	List<BookBoardBean> getAllgenre();
	List<BookBoardBean> getAllList();
	List<BookBoardBean> getNobleGenre();
	List<BookBoardBean> getDevelopGenre();
	List<BookBoardBean> getForeignLanguageGenre();
	List<BookBoardBean> getItGenre();	
	List<BookBoardBean> getSearchList(String keyword);
	
	public BookBoardBean read(int boardNo)throws Exception;
	public void upviews(int boardNo);
	//댓글 등록시 댓글 갯수+1 반영
	public void BookUpdate();

}