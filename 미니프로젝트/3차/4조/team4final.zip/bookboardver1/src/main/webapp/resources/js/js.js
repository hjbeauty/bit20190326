function idOverlap(){
	$.ajax({
		type :"post",
		url :"joinIdCheck",
		data : {"id" : joinForm.id.value},
		dataType : "text",
	
		success : function(data){	
			if(data=="1"){
				alert("사용 가능한 아이디입니다.");
			}else{
				alert("아이디가 중복됩니다.");
			}
		},
		
		error : function(){
		alert("아이디 중복 확인 ajax 실행 실패");
		}
	});
}


function loginCheck(){
	var form= document.loginForm;
	
	if(!form.id.value){
		alert("아이디를 입력하세요");
		return false;
	}
	
	if(!form.password.value){
		alert("비밀번호를 입력하세요.")
		return false;
	}
	
}

function checkValue(){
	
	var form= document.joinForm;	
	var cID = RegExp(/^[a-zA-Z0-9]{4,15}$/);
	// 영문, 특수문자, 숫자 조합으로 8~20자
	var cPW = RegExp (/^(?=.*[a-zA-Z])(?=.*[^a-zA-Z0-9])(?=.*[0-9]).{8,20}$/);
	var cMail = RegExp(/^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/);
	var cName = RegExp(/^[가-힣]{2,5}$/);	
	var cPhone = RegExp(/^01(?:0|1|[6-9])\d{3,4}\d{4}$/);	
	
	if(!form.id.value){
		alert("아이디를 입력하세요");
		return false;
	}
	
	if(!cID.test(form.id.value)){
		alert("아이디는 영문/숫자 활용하여 4자 이상 15자 이하로 만들어주세요");
		return false;
	}
	
	if(!form.password.value){
		alert("비밀번호를 입력하세요.")
		return false;
	}
	
	if(!cPW.test(form.password.value)){
		alert("비밀번호는 영문, 특수문자, 숫자 조합으로 8~20자 이하로 만들어주세요");
		return false;
	}
	
	if(!form.password2.value){
		alert("비밀번호 확인을 입력해주세요")
		return false;
	}
	
	if(form.password.value != form.password.value){
		alert("비밀번호가 일치하지 않습니다.")
		return false;
	}
	if(!form.name.value){
		alert("이름을 입력해주세요")
		return false;
	}
	
	if(!cName.test(form.name.value)){
		alert("이름은 한글 2~5자 사이로 입력해주세요");
		return false;
	}
	
	if(!form.phone.value){
		alert("휴대전화를 입력해주세요")
		return false;
	}
	
	if(!cPhone.test(form.phone.value)){
		alert("- 빼고 올바른 휴대전화 번호를 입력해주세요");
		return false;
	}
	
	if(!form.email.value){
		alert("이메일을 입력해주세요")
		return false;
	}
	
	if(!cMail.test(form.email.value)){
		alert("메일주소 형식이 올바르지 않습니다.");
		return false;
	}
}